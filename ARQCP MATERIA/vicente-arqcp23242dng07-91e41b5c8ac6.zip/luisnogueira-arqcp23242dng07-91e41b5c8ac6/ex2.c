#include <stdio.h>

int main() {
    double doubleVar = 3.14;
    int intVar = 42;
    char charVar = 'A';

    double *ptrDouble = &doubleVar;
    int *ptrInt = &intVar;
    char *ptrChar = &charVar;

    printf("Double Variable:\n");
    printf("Address: %p\n", &doubleVar);
    printf("Value: %lf\n", doubleVar);
    printf("Memory Size (bytes): %lu\n", sizeof(double));

    printf("\nInt Variable:\n");
    printf("Address: %p\n", &intVar);
    printf("Value: %d\n", intVar);
    printf("Memory Size (bytes): %lu\n", sizeof(int));

    printf("\nChar Variable:\n");
    printf("Address: %p\n", &charVar);
    printf("Value: %c\n", charVar);
    printf("Memory Size (bytes): %lu\n", sizeof(char));

    printf("\nPointer to Double Variable:\n");
    printf("Address: %p\n", ptrDouble);
    printf("Value: %lf\n", *ptrDouble);
    printf("Memory Size (bytes): %lu\n", sizeof(double *));

    printf("\nPointer to Int Variable:\n");
    printf("Address: %p\n", ptrInt);
    printf("Value: %d\n", *ptrInt);
    printf("Memory Size (bytes): %lu\n", sizeof(int *));

    printf("\nPointer to Char Variable:\n");
    printf("Address: %p\n", ptrChar);
    printf("Value: %c\n", *ptrChar);
    printf("Memory Size (bytes): %lu\n", sizeof(char *));

    return 0;
}
