#include <stdio.h>
#include "asm.h"

int main() {
    int array[5] = {10,10,10,10,10};
    short n = 5;
    
    int result = vec_avg(array, n);
    printf("Vec avg: %d\n", result);
    

    return 0;
}
