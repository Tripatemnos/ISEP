#ifndef ASM_H
#define ASM_H

int vec_sum(int* ptr, short num);
int vec_avg(int* ptr, short num);

#endif
