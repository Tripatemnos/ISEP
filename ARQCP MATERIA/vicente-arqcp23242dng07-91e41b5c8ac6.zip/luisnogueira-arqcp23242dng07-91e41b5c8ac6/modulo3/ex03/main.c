#include <stdio.h>
#include "asm.h"

int main() {
    char str1[] = "One uU";
    char str2[100];

    str_copy_roman2(str1, str2);
    printf("Original string: %s\n", str1);
    printf("Modified string: %s\n", str2);

    return 0;
}
