#ifndef ASM_H
#define ASM_H

void str_copy_roman2(char* ptr1, char* ptr2);

#endif
