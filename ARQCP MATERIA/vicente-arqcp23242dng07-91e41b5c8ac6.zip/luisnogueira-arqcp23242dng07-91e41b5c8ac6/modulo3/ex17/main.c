#include <stdio.h>
#include "asm.h"

int main() {
    int array[100] = {-1,-3,-2};
    int num = 3;

    array_sort(array, num);

    printf("Resultado: ");
    for (int i = 0; i < num; i++) {
        printf("%d ", array[i]);
    }
    printf("\n");

    return 0;
}

