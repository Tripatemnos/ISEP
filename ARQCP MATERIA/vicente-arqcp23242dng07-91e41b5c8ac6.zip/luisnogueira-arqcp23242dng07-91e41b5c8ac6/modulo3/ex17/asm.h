#ifndef ASM_H
#define ASM_H

void array_sort(int* ptr, int num);

#endif
