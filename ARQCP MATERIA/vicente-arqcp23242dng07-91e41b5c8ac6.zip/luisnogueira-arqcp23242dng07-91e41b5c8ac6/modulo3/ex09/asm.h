#ifndef ASM_H
#define ASM_H

int* vec_search(int* ptr, int num, int x);

#endif
