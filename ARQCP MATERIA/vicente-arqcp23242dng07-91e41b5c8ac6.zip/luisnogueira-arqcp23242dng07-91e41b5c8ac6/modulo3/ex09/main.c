#include <stdio.h>
#include "asm.h"

int main() {
    int array[100] = {-1, -1, -1, -3};
    int num = 4;
    int x = -3;

    int* resultado = vec_search(array, num, x);
    printf("Resultado: %p\n", resultado);

    return 0;
}

