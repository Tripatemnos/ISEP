#include <stdio.h>
#include "asm.h"

int main() {
    char grades[100] = {0};
    int num = 0;
    int freq[21] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

    frequencies(grades, num, freq);

    printf("Resultado: ");
    for (int i = 0; i < 21; i++) {
        printf("%d ", freq[i]);
    }
    printf("\n");

    return 0;
}

