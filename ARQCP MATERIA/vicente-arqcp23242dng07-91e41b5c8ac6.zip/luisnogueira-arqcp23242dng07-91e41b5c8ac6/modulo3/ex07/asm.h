#ifndef ASM_H
#define ASM_H

int decrypt(char* ptr);

#endif
