#include <stdio.h>
#include "asm.h"

int main() {
    char str[100] = " aeea ";
    
    int resultado = decrypt(str);
    printf("Contador: %d\n", resultado);
    

    return 0;
}
