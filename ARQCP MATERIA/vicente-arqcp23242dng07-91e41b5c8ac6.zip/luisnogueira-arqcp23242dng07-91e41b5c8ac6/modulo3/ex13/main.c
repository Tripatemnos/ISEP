#include <stdio.h>
#include "asm.h"

int main() {
    int array[100] = {1000, 10000, 20000, -1000, -5000};
    int num = 5;

    keep_positives(array, num);

    printf("Resultado: ");
    for (int i = 0; i < num; i++) {
        printf("%d ", array[i]);
    }
    printf("\n");

    return 0;
}

