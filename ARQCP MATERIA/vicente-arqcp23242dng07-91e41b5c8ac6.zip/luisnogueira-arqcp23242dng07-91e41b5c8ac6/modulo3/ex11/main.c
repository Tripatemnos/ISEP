#include <stdio.h>
#include "asm.h"

int main() {
    int array[100] = {1001,10000,0x10000001};
    int num = 3;

    int resultado = vec_greater12(array, num);
    printf("Resultado: %d\n", resultado);

    return 0;
}

