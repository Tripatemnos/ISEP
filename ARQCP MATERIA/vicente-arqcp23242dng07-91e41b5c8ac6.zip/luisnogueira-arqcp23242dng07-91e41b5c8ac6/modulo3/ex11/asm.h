#ifndef ASM_H
#define ASM_H

int vec_greater12(int* ptr, int num);

#endif
