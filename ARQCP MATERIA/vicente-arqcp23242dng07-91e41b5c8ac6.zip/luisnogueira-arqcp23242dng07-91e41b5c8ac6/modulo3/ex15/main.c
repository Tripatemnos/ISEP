#include <stdio.h>
#include "asm.h"

int main() {
    long array[100] = {0x10000,0x22222,0x33333,0x44444,0x10000,0x22222,0x33333,0x44444,0x00000};
    int num = 9;

    int resultado = sum_third_byte(array, num);

    printf("Resultado: %d\n", resultado);

    return 0;
}

