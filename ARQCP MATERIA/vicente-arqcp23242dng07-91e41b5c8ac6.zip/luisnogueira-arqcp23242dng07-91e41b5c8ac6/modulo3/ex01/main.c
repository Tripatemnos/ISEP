#include <stdio.h>
#include "asm.h"

int main() {
    char str[100];

    printf("Enter a string: ");
    scanf("%99s", str);

    int result = five_count(str);
    printf("Number of 5s: %d\n", result);
    return 0;
}
