#ifndef ASM_H
#define ASM_H

int five_count(char* ptr);

#endif
