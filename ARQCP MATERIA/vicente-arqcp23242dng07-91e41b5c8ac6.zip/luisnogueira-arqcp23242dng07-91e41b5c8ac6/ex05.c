#include <stdio.h>

int sum_even(int *vec,int n){
	int sum =0;
for( int i =0; i<n ; i++){
	
	
	if(*(vec+i) %2==0){
	sum += *(vec +i);
	}
}	
	return sum;
}


int main(){

int vec[] = {1,2,3,4,5,6};
int n=sizeof(vec)/sizeof(vec[0]) ;

int result = sum_even(vec,n);

printf(":%d",result);

return 0;
}
