#include <stdio.h>
#include "asm.h"

int main() {
    int circular_buffer[5];  // Tamanho do buffer circular
    int read_pointer = 0;
    int write_pointer = 0;

    // Inserir valores no buffer usando a função em assembly
    enqueue_value(circular_buffer, 5, &read_pointer, &write_pointer, 10);
    enqueue_value(circular_buffer, 5, &read_pointer, &write_pointer, 20);
    enqueue_value(circular_buffer, 5, &read_pointer, &write_pointer, 30);
    enqueue_value(circular_buffer, 5, &read_pointer, &write_pointer, 40);
    enqueue_value(circular_buffer, 5, &read_pointer, &write_pointer, 50);
    enqueue_value(circular_buffer, 5, &read_pointer, &write_pointer, 60);
    // Leitura do buffer (neste exemplo, apenas exibindo os valores)
 for (int i = 0; i < 5; ++i) {
    printf("Buffer[%d]: %d\n", i, circular_buffer[i]);
}


    return 0;
}
