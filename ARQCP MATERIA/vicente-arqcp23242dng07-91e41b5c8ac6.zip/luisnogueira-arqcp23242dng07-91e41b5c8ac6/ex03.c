#include <stdio.h>

void capitalize(char *str){
	if(str==NULL || *str=='\0'){
		return;
}
while(*str !='\0'){
	if(*str>='a'&& *str <='z'){
		*str =*str - 32;
}
str++;
}
}

int main(){
	char string  []= "PALAVRA";
	
	capitalize(string);
	
	printf(string);
	return 0;
}
