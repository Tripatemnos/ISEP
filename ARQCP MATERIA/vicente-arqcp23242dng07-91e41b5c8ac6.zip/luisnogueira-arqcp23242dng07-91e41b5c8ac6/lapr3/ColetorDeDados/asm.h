#ifndef ASM_H
#define ASM_H

void extract_token(char* input, char* token, int* output);

#endif
