#ifndef COLETORDEDADOS_H
#define COLETORDEDADOS_H
void extract_token(char* input, char* token, int* output);

#endif
