#ifndef ASM_H
#define ASM_H

void enqueue_value(int* array, int length, int* read, int* write, int value);

#endif
