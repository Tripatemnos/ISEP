#include <stdio.h>
#include "asm.h"

int main() {
    // Test the mediana function
    int array[] = {1, 3, 5, 7, 9, 11};  // Example array
    int array_size = sizeof(array) / sizeof(array[0]); // Calculate number of elements in array
    int median_value = mediana(array, array_size); // Call the mediana function
    printf("The median value is: %d\n", median_value); // Output the median value

    return 0;
}
