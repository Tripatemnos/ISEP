#ifndef ASM_H
#define ASM_H


int mediana(int* vec, int num);


#endif
