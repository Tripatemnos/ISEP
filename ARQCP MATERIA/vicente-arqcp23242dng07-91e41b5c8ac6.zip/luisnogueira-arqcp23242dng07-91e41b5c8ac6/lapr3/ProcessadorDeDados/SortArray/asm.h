#ifndef ASM_H
#define ASM_H

void sort_array(int* vec, int num);


#endif
