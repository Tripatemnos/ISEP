#include <stdio.h>
#include "asm.h"

int main() {
    int vec[] = {4, 2, 3, 1, 5};
    int num = sizeof(vec) / sizeof(vec[0]);

    // Call the assembly function to sort the array
    sort_array(vec, num);

    // Print the sorted array
    printf("Sorted array: ");
    for(int i = 0; i < num; i++) {
        printf("%d ", vec[i]);
    }
    printf("\n");

    return 0;
}
