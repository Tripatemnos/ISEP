#ifndef ASM_H
#define ASM_H

int move_num_vec(int *array, int length, int *read_index, int *write_index, int num, int *vec);

#endif // ASM_H
