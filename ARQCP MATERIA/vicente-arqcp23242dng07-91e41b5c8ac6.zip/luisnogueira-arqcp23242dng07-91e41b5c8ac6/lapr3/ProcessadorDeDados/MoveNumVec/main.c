#include <stdio.h>
#include "asm.h"

int main() {
    int circular_buffer[10] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    int read_index = 0;
    int write_index = 0;
    int destination[5];
    int success;
	
    // Pass pointers to read_index and write_index, as per function prototype
    success = move_num_vec(circular_buffer, 10, &read_index, &write_index, 5, destination);

    if (success) {
        printf("Elements moved successfully:\n");
        for (int i = 0; i < 5; ++i) {
            printf("%d ", destination[i]);
        }
        printf("\n");
    } else {
        printf("Not enough elements to move.\n");
    }

    return 0;
}
