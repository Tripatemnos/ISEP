long steps(long num);
