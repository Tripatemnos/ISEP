#include <stdio.h>
#include "steps.h"

int main() {
    long inputNumber = 33;  // Substitua pelo valor de entrada desejado

    long result = steps(inputNumber); // Chama a função assembly

    printf("Resultado: %ld\n", result);

    return 0;
}
