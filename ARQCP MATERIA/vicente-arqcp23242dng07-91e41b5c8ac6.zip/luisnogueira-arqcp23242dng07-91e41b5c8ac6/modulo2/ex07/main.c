#include <stdio.h>
#include "asm.h"
short s1 = 0x1234;
short s2 = 0x5678;
short result;
int main(void) {
printf("\nValor não alterado: %X\n", s1);
printf("\nValor não alterado: %X\n", s2);
result =crossSubBytes();
printf("\nValor alterado: %X\n", result);
return 0;
}
