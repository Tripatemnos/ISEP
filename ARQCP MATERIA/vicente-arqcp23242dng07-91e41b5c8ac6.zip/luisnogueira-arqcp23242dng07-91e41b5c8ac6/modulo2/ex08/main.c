#include <stdio.h>
#include "asm.h"

extern short s1;     // Declare s1 como extern para acessá-lo em main.c
extern short s2;     // Declare s2 como extern para acessá-lo em main.c
extern short result; // Declare result como extern para acessá-lo em main.c

int main(void) {
    printf("\nValor não alterado: %X\n", s1);
    printf("\nValor não alterado: %X\n", s2);
    result = crossSubBytes();
    printf("\nValor alterado: %X\n", result);
    return 0;
}
