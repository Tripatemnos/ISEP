#ifndef ASM_H
#define ASM_H
char verify_flags();
#endif
