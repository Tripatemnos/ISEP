#include <stdio.h>
#include "asm.h"

char current , desired ; 
short result;

int main() {
	printf("insert current: \n");
	getchar();
	scanf(" %c",&current);
	
	printf("insert desired:");
	scanf(" %c",&desired);
	
	
	result = needed_time();
	printf("Result: %hd\n", result);
	
	return 0;
}
