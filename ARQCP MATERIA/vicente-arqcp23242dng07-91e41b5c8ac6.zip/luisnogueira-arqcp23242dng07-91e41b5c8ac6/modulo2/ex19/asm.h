#ifndef ASM_H
#define ASM_H
short needed_time();
#endif
