#include <stdio.h>
#include "asm.h"

int64 op1 = 0;
int64 op2 = 0;
int64 op3 = 0;
int64 op4 = 0;

int main(void) {
    printf("Valor op1: ");
    scanf("%ld", &op1);  
    printf("Valor op2: ");
    scanf("%ld", &op2);
    printf("Valor op3: ");
    scanf("%ld", &op3);
    printf("Valor op4: ");
    scanf("%ld", &op4);

    int64 result = yet_another_sum();

    printf("Resultado: %ld\n", result);  
    return 0;
}
