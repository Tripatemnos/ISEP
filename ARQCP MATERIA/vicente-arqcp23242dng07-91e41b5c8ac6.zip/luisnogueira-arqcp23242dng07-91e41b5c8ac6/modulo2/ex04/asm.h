typedef long int64;

extern int64 op3;
extern int64 op4;

int64 yet_another_sum(void);
