#ifndef ASM_H
#define ASM_H
int new_salary();
#endif
