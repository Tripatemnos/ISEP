#include <stdio.h>
#include "asm.h"

short code, currentSalary ;	
						

int main() {
	printf("Position code:\n");
	scanf("%hd",&code);
	printf("Current Salary:\n");
	scanf("%hd",&currentSalary);

	printf("\nNew Salary of Manager: %d\n", new_salary());
	return 0;
}
