#include <stdio.h>
#include "sigma.h"

int main() {
    int n = 5;  // Replace with the value of n you want to calculate

    int result = sigma(n);

    printf("Result: %d\n", result);

    return 0;
}
