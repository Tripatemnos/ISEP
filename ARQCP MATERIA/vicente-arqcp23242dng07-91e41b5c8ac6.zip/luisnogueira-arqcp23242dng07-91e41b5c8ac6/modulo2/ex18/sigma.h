int sigma(int n);
