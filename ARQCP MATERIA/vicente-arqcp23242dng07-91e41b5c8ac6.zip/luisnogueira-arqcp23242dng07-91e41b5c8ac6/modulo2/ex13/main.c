#include <stdio.h>
#include "asm.h"

short lenght1;
short lenght2;
short height;
int area;
int main(void) {
	printf("Valor lenght1:\n");
	scanf("%hd",&lenght1);
	printf("Valor lenght2:\n");
	scanf("%hd",&lenght2);
	printf("Valor height:\n");
	scanf("%hd",&height);

	area=getArea();
    printf("Area:%d", area);
return 0;
}
