#ifndef ASM_H
#define ASM_H
long another_sum(void);
extern long op1;
extern long op2;
#endif
