#include <stdio.h>
#include "asm.h"
long op1=0, op2=0,res=0;
int main(void) {
printf("Valor op1:");
scanf("%ld",&op1);
printf("Valor op2:");
scanf("%ld",&op2);
res = another_sum();
printf("sum = %ld:\n", res);
return 0;
}
