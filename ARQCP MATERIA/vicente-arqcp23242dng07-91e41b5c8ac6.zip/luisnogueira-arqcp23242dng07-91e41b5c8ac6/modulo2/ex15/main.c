#include <stdio.h>
#include "asm.h"

int A;
int B;
int C;
int D;
int result;
int main(void) {
	printf("Valor A:\n");
	scanf("%d",&A);
	printf("Valor B:\n");
	scanf("%d",&B);
	printf("Valor C:\n");
	scanf("%d",&C);
	printf("Valor D:\n");
	scanf("%d",&D);
	result=compute();
    printf("Area:%d", result);
return 0;
}
