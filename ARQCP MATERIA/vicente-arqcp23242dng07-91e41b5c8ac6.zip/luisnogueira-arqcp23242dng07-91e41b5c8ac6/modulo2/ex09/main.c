#include <stdio.h>
#include "asm.h"
int A=3 ;
char B=2 ;
short C=10;
short D=8;
long result;
int main(void) {
result=sum_and_subtract();
printf("\nResultado: %ld\n", result);
return 0;
}
