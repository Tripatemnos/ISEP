typedef long long int64;

typedef int int32;

extern int32 op1;
extern int32 op2;
extern int32 op3;

extern int64 result;

int64 sum3units(void);
