#include <stdio.h>
#include "exchanged_bytes.h"

int16 op1 = 0;
int16 op2 = 0;

int main(void) {
    printf("Valor op1: ");
    scanf("%hd", &op1);  // Use "%hd" for reading a 16-bit signed integer
    printf("Valor op2: ");
    scanf("%hd", &op2);

    int16 result = exchanged_bytes();

    printf("Resultado: %hd\n", result);  // Use "%hd" to print a 16-bit signed integer
    return 0;
}
