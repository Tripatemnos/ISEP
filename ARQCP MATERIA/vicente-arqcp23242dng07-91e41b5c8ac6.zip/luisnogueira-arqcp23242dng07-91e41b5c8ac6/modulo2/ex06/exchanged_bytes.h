typedef short int16;

extern int16 op1;
extern int16 op2;

int16 exchanged_bytes(void);
