#include <stdio.h>
#include "isMultiple.h"

long A = 0;
long B = 0;

int main(void) {
	
    printf("Valor de A: ");
    scanf("%ld", &A);
    
    printf("Valor de B: ");
    scanf("%ld", &B);

    int result = isMultiple();

    if (result == 1) {
        printf("A é múltiplo de B.\n");
    } else {
        printf("A não é múltiplo de B.\n");
    }

    return 0;
}
