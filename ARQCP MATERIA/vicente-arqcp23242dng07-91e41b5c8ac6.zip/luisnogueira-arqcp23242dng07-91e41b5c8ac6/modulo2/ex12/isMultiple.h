extern long A;
extern long B;

int isMultiple(void);
