void swap_nums(int *x, int *y);
