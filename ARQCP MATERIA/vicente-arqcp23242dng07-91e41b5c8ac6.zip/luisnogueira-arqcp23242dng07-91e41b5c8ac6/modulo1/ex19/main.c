#include <stdio.h>
#include "swap.h"


int main(){

short vec1[]={10,5,3,6,7,3,5,65,3,23,25};
int n =(sizeof(vec1)/sizeof(vec1[0]));
short vec2[]={2,5,76,9,243,4,5,74,2,47,21};


swap(vec1,vec2,n);
	printf("vec1");
	printf("\n");

for(int i=0;i<n;i++){
	printf("\n");
	printf("%d",vec1[i]);

}
	printf("\n");
	printf("vec2");

for(int i=0;i<n;i++){
	printf("\n");
	printf("%d",vec2[i]);

}
    
	return 0;
	
	
}
