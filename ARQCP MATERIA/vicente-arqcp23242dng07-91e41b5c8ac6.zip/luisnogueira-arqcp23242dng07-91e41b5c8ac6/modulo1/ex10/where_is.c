#include <stdio.h>

char* where_is(char *str, char c) {
    while (*str != '\0') {
        if (*str == c) {
            return str;  // Return the address of the character
        }
        str++;  // Move to the next character
    }
    
    return NULL;  // Character not found, return NULL
}
