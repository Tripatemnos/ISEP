#include <stdio.h>
#include "where_is.h"

int main() {
    char input[] = "Habbibi, welcome";
    char target = 'l';
    
    char *result = where_is(input, target);
    
    if (result != NULL) {
        printf("Character '%c' found at position %ld\n", target, result - input);
    } else {
        printf("Character '%c' not found in the string.\n", target);
    }
    
    return 0;
}
