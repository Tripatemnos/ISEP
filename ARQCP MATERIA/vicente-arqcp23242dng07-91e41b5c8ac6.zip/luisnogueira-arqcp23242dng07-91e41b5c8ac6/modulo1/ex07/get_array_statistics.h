void get_array_statistics(int* vec, int n, int* min,int* max,float* avg){
	
	if (n == 0) {
        *min = 0;
        *max = 0;
        *avg = 0.0;
        return;
    }

    *min = *vec;
    *max = *vec;

    int sum = 0;
    
    int* ptr = vec;
    for (int i = 0; i < n; i++) {
      
        if (*ptr < *min) {
            *min = *ptr;
        }
	 if (*ptr > *max) {
            *max = *ptr;
        }

        sum += *ptr;

        ptr++;
    }

    *avg = (float)sum / n;
}

