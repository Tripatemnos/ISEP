void get_statistics(int* vec, int n, int* min,int* max,float* avg);
