#include <stdio.h>

int main() {
	
	double anyDouble = 2.61523;
	int anyInt = 6;
	char anyChar = 'D';
	
	double *anyDoublePtr = &anyDouble;
	int *anyIntPtr = &anyInt;
	char *anyCharPtr = &anyChar;
	
	printf("Adress of anyDouble: %p\n", (void *)anyDoublePtr);
	printf("Value of anyDouble: %lf\n", anyDouble);
	printf("Memory size of anyDouble: %lu bytes\n", sizeof(anyDouble));
	
	printf("Adress of anyInt: %p\n", (void *)anyIntPtr);
	printf("Value of anyInt: %d\n", anyInt);
	printf("Memory size of anyInt: %lu bytes\n", sizeof(anyInt));
	
	printf("Adress of anyChar: %p\n", (void *)anyCharPtr);
	printf("Value of anyChar: %c\n", anyChar);
	printf("Memory size of anyDouble: %lu bytes\n", sizeof(anyChar));
	
	
	return 0;
}
