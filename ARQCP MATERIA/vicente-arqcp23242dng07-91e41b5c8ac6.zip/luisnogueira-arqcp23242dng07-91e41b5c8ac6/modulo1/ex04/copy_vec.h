void copy_vec(int *vec1, int n, int *vec2);
