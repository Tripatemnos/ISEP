#include <stdio.h>

void copy_vec(int *vec1, int n, int *vec2){
	
	for(int i = 0; i < n; i++){
		*(vec2 + i) = *(vec1 + i);
	}
	
	printf("Elementos copiados com sucesso \n");
	
	
	
	for (int i = 0 ; i < 9; i++){
		
		printf("%d \n", vec2[i]);
	}
}
