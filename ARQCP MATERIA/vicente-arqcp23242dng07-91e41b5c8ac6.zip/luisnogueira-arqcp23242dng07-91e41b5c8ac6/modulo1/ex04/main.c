#include <stdio.h>
#include "copy_vec.h"

int main(){
	
	int vec1[] = {1,2,3,4,5,6,7,8,9};
	int vec2[9];
	
	copy_vec(vec1, 9, vec2);
	
	
	
	
	return 0;
}
