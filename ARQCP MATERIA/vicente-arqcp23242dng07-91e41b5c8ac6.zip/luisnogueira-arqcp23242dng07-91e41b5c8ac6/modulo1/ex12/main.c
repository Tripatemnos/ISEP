#include <stdio.h>
#include "array_sort.h"

int main() {
    int arr[] = {20, 12, 65, 12, 51, 60};
    int n = sizeof(arr) / sizeof(arr[0]);

    printf("Original array: ");
    for (int i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }

    array_sort(arr, n);

    printf("\nSorted array: ");
    for (int i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }
    
    printf("\n");

    return 0;
}
