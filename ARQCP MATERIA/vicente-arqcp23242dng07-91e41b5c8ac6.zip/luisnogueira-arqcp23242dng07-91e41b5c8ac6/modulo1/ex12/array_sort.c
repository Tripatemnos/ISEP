#include <stdio.h>

void array_sort(int *vec, int n) {
    int temp;
    int *end = vec + n - 1;

    for (int i = 0; i < n - 1; i++) {
        int *ptr = vec;
        int *next_ptr = vec + 1;

        for (int j = 0; j < n - i - 1; j++) {
            if (*ptr > *next_ptr) {
                temp = *ptr;
                *ptr = *next_ptr;
                *next_ptr = temp;
            }

            ptr = next_ptr;
            next_ptr++;
        }
    }
}
