
void trim_string(char* str) {
    int spaces = 0; 
    char* dest = str; 

    while (*str) {
        if (*str != ' ') {
            *dest = *str;
            spaces = 0;
            dest++;
        } else {
            if (spaces == 0) {
                *dest = ' ';
                spaces = 1;
                dest++;
            }
        }
        str++;
    }

    *dest = '\0';
}



