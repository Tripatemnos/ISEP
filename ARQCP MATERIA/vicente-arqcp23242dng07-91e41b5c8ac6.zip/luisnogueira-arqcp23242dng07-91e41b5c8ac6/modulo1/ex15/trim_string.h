void trim_string(char *str);
