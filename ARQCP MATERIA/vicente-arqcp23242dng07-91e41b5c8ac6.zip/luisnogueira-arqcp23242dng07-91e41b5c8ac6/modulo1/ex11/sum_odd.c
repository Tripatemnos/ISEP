int sum_odd(int *p){
	int sum=0;
	int n=*p;
	int *ptr = p+1;
	for(int i=0; i<n;i++){
	
	if(*ptr%2 != 0){
	sum+=*ptr;
	
	}
	else{
		
		
	}
	ptr++;
	}
	return sum;
	
	
}
