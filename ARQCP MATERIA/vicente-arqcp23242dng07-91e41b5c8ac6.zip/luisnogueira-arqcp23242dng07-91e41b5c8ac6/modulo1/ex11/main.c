#include <stdio.h>
#include "sum_odd.h"


int main (){

int vec []={5,10,11,23,35,2};
int r=sum_odd(vec);	

	printf(":%d",r);
	
	
	return 0;
}
