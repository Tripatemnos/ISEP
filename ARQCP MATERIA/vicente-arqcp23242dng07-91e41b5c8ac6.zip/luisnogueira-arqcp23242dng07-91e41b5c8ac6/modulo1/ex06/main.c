#include <stdio.h>
#include "capitalize2.h"

int main() {
    char text[] = "Esteroides é bom";
    printf("Original: %s\n", text);

    capitalize2(text);

    printf("Capitalized: %s\n", text);

    return 0;
}

