#include <stdio.h>

int check(unsigned char x, unsigned char y, unsigned char z) {
    return (x < y && y < z);  // Check if the condition is satisfied
}
