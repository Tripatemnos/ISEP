#include <stdio.h>

static int num_sets = 0;  // Global variable to store the number of sets

void inc_nsets() {
    num_sets++;  // Increment the number of sets
}

int get_nsets() {
    return num_sets;  // Get the total number of sets
}
