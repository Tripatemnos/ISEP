#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void populate(unsigned char *vec, int num, unsigned char limit) {
    srand(time(NULL));  // Seed for random number generation
    for (int i = 0; i < num; i++) {
        vec[i] = rand() % (limit + 1);  // Generate random values between 0 and limit
    }
}
