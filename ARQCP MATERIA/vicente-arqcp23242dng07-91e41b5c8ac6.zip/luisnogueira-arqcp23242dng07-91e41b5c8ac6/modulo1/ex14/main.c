#include <stdio.h>
#include "count_words.h"

int main() {
    char str[] = " Que boa COCAcola";
    count_words(str);
    return 0;
}
