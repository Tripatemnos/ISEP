#include <stdio.h>

void count_words(char *str) {
    int count = 0;
    int is_inside_word = 0; 

    while (*str) {
        if (*str == ' ' || *str == '\t' || *str == '\n' || *str == '\r' || *str == '\f' || *str == '\v' || *str == '\0') {
            
            if (is_inside_word) {
                count++;
                is_inside_word = 0; 
            }
        } else {
            is_inside_word = 1; 
        }
        str++; 
    }

    printf("Number of words: %d\n", count);
}
