void count_words(char *str);
