#include <stdio.h>

void compress(int* vec_ints, int n, long* vec_longs) {
    for (int i = 0, j = 0; i < n; i += 2, j++) {
        long compressed = ((long)vec_ints[i] << 32) | (vec_ints[i + 1]);
        vec_longs[j] = compressed;
    }
}
