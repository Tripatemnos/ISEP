#include <stdio.h>
#include "capitalize.h"

int main(){
	char string  []= "Palavra";
	
	capitalize(string);
	
	printf(string);
	return 0;
}
