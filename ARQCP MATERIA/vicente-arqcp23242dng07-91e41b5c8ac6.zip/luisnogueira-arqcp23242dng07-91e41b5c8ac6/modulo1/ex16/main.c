#include <stdio.h>
#include "format_string.h"

int main() {
    char str[] = "  que BOa     CoCACOLa   CERTO";
    
    format_string(str);
    
    printf("%s\n", str);
    
    return 0; 
}
