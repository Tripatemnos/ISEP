#include <stdio.h>
#include <ctype.h>

void format_string(char *str) {
    int cap = 1;  
    
    while (*str) {
        if (isspace(*str)) {
            
            cap = 1;
            
            while( isspace(*(str + 1))){
				str++;	
			}
				
        } else {
            if (cap) {
                
                *str = toupper(*str);
                cap = 0;
            } else {
                
                *str = tolower(*str);
            }
        }
        str++;
    }
}
