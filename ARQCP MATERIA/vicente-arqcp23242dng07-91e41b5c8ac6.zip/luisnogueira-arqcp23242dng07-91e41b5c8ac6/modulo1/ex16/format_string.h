void format_string(char *str);
