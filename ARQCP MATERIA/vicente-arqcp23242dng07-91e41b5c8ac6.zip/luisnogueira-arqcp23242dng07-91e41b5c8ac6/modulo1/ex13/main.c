#include <stdio.h>
#include "sort_without_reps.h"

int main(){
	
	short src[]={0,4,8,5,3,2,3,2,9,6};
	int n = (sizeof(src))/(sizeof(src[0]));
	short dest[n];
	
	int r=sort_without_reps(src,n,dest);
	for(int i=0; i<r;i++){
		
	printf("%d",dest[i]);
}
	
	return 0;
}
