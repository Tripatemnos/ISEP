int sum_integer_bytes(unsigned int *p) {
 int sum = 0;

    unsigned char* bytePointer = (unsigned char*)p;
	 int n = (sizeof(*p));
    for (int i = 0; i < n ; i++) {
        sum += *bytePointer;
        bytePointer++; 
    }

    return sum;
}

