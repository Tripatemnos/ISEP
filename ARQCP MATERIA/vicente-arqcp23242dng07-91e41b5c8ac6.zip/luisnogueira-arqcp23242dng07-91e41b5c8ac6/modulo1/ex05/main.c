#include <stdio.h>
#include "sum_even.h"

int main(){

int vec[] = {1,2,3,4,5,6};
int n=sizeof(vec)/sizeof(vec[0]) ;

int result = sum_even(vec,n);

printf(":%d",result);

return 0;
}
