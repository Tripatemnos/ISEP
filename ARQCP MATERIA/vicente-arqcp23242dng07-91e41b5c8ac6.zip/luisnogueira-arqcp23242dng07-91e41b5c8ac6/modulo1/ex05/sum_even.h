int sum_even(int *vec,int n);
