int new_salary();
