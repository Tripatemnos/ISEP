#include <stdio.h>
#include "salary.h"

short code = 20, currentSalary = 500;	
						

int main() {
    //Expected to be 750€ (500 + 250)
	printf("\nNew Salary of Manager: %d\n", new_salary());
	return 0;
}
