#include <stdio.h>
#include "asm.h"

short s1=1, s2=3;
int main(){
    printf("\nResult: %d\n", crossSubBytes());
    return 0;
}
