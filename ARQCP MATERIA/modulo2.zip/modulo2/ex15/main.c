#include <stdio.h>
#include "asm.h"

int A,B,C,D;

int main() {
    // Values for variables A, B, C, and D
  A = 10;
 B = 5;
  C = 3;
D = 2;

    // Call the assembly function and store the result in the variable result
    int result = compute(A, B, C, D);

    // Print the result
    printf("Result: %d\n", result);

    return 0;
}

