int getArea();
