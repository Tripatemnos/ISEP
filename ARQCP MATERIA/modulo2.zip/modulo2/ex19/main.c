#include <stdio.h>
#include "time.h"

char current, desired;
short result;
int main(){
	current=20;
	desired=18;
	result = needed_time();
	printf("\nResult: %d\n", result);
	
	return 0;

	



}
