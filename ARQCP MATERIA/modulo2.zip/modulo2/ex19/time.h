short needed_time();
