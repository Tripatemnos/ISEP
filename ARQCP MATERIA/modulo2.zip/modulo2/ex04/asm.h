#ifndef ASM_H
#define ASM_H
long yet_another_sum();
extern long op3;
extern long op4;
#endif
