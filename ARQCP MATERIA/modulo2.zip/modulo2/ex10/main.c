#include <stdio.h>
#include "sum3ints.h"

int main() {
    long op1 = 10;
    long op2 = 20;
    long op3 = 30;

    long long result = sum3ints(op1, op2, op3);

    printf("Result: %lld\n", result);

    return 0;
}
