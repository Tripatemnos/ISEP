#ifndef SUM3INTS_H
#define SUM3INTS_H

long long sum3ints(long op1, long op2, long op3);

#endif
