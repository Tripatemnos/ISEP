#include <stdio.h>
#include "asm.h"

    int A = 100;  // exemplo de valor para A (32-bit)
    char B = 10;    // exemplo de valor para B (8-bit)
    short C = 500;   // exemplo de valor para C (16-bit)
    short D = 200;   // exemplo de valor para D (16-bit)

int main() {

    long result = sum_and_subtract(A, B, C, D);

    printf("Resultado da operacao C - A + D - B: %ld\n", result);

    return 0;
}
