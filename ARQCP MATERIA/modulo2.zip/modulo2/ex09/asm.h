long sum_and_subtract();
