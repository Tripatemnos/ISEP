#include <stdio.h>
#include "asm.h"
	short op1 = 32767; 
    short op2 = 1;
int main() {
    
    int result = verify_flags(op1, op2);
    printf("Resultado: %d\n", result);  

    op1 = -32768;  
    op2 = -1;
    result = verify_flags(op1, op2);
    printf("Resultado: %d\n", result);  

    op1 = 100;
    op2 = 200;
    result = verify_flags(op1, op2);
    printf("Resultado: %d\n", result);  

    return 0;
}
