#ifndef SWAP_H
#define SWAP_H

short swapBytes();

#endif

