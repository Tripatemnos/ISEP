char check_num();
