#include <stdio.h>
#include "exchangeBytes.h"
short op1, op2;
int main(){

	op1 = 0x1234; 
    op2 = 0x5678;  

    short result = exchangeBytes(op1, op2);

    printf("Result: 0x%04X\n", result);

return 0;
}
