short exchangeBytes(short op1, short op2);
