#include <stdio.h>
#include "steps.h"

long num = 5;

int main() {
    int result = steps();
    printf("Result: %d\n", result);
    return 0;
}
