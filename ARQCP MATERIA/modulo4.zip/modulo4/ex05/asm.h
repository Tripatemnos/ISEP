#ifndef ASM_H
#define ASM_H

long inc_and_cube(short *v1, int v2);

#endif
