#ifndef ASM_H
#define ASM_H

int calculate(int a, int b);

#endif
