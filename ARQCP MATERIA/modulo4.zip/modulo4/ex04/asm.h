#ifndef ASM_H
#define ASM_H

int sum_sub(int num1, int num2, int *ptrsub);

#endif
