#ifndef CODIFICA_H
#define CODIFICA_H
int set_value(int data,char *token,int n,short pattern);
 #endif
