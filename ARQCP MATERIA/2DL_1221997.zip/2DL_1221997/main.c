#include <stdio.h>
#include "codifica.h"
#include "descodifica.h"

int main() {
	
	//iniciar variaveis
	
	int data;
	short pattern;
	char token[17];
	int n = sizeof(token);
	
	int codifica=0;
	int decoded_value=0;
	
	codifica = set_value(data,token,n,pattern);

    if (codifica==1) {
        printf("Insert value: %s\n", token);

        decoded_value = get_value(token);
        printf("Decoded value: %d\n", decoded_value);
    } else {
        printf("String error\n");
    }
    return 0;
}
