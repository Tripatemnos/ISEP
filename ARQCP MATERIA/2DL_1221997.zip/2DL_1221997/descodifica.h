#ifndef DESCODIFICA_H
#define DESCODIFICA_H
 get_value(char *token);
 #endif
