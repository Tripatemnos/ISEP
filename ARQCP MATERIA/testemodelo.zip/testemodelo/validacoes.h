int validar_pressao(unsigned int passador);
int fechar_passadores(unsigned int *passadores, int n, unsigned int *fechados);
