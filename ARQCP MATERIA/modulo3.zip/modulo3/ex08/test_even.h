int test_even(int x);
int vec_sum_even(int*ptr, int num);
