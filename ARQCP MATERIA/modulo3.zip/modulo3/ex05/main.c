
#include "vec_sum.h"
#include "vec_avg.h"
#include <stdio.h>

int array[] = { -1, -1, -1};
int * ptrvec = array;
short num = 3;

int main(){
   
    int sum = vec_sum(ptrvec, num);
    printf("\nThe sum of the elements is %d\n", sum);
    int result = vec_avg(ptrvec, num);
    printf("\nThe average of the vector is %d\n", result);
    return 0;
    }
