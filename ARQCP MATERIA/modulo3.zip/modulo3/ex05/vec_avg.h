int vec_avg(int* ptr, short num);
