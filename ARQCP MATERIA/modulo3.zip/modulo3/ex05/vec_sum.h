int vec_sum(int* ptr, short num);
