int* vec_search(int* ptr, int num, int x);
