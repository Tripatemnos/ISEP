#include "vec_search.h"
#include <stdio.h>

int array[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
int * ptrvec = array;
int x = 5;
int num = 10;

int main(){
    printf("Address: %p\n", vec_search(ptrvec, num, x));
    return 0;
}
