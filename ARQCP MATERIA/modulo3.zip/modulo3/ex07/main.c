#include <stdio.h>
#include "decrypt.h"
char word[] = "Ifmmp aohfmjoa";
char * ptr1 = word;

int main(){
    printf("\nEncrypted: %s\n", ptr1);
    decrypt(ptr1);
    printf("\nNot Encrypted: %s\n", ptr1);
    return 0;
}
