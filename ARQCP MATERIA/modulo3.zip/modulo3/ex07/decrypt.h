int decrypt(char* ptr);
