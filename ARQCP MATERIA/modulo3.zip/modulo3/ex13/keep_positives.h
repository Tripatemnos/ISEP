void keep_positives(int* ptr, int num);
