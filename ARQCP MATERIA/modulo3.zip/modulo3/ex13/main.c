#include "keep_positives.h"
#include <stdio.h>


int main() {
    int array[] = {5, -3, 8, -2, 7, -1};
    int length = sizeof(array) / sizeof(array[0]);

    printf("Original Array: ");
    for (int i = 0; i < length; i++) {
        printf("%d ", array[i]);
    }

    keep_positives(array, length);

    printf("\nModified Array: ");
    for (int i = 0; i < length; i++) {
        printf("%d ", array[i]);
    }

    printf("\n");

    return 0;
}
