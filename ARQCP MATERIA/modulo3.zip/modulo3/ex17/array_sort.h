void array_sort(int* ptr, int num);
