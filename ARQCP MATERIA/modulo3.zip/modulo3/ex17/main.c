#include <stdio.h>
#include "array_sort.h"

int main() {
    int array[] = {4, 2, 7, 1, 9, 5, 3, 8, 6};
    int num = sizeof(array) / sizeof(array[0]);
    
    printf("Original array: ");
    for (int i = 0; i < num; ++i) {
        printf("%d ", array[i]);
    }
    printf("\n");

    array_sort(array, num);

    printf("Sorted array: ");
    for (int i = 0; i < num; ++i) {
        printf("%d ", array[i]);
    }
    printf("\n");

    return 0;
}
