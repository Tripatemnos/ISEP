#include <stdio.h>
#include "vec_greater.h"

int array[] = { 20, 300, 500, 2, 7, 1000, 550, 700, 60, 12, 5, 20, 878, 1, 4 };
int * ptrvec = array;
int num = sizeof(array)/sizeof(int);

int main() {
    
    int total = vec_greater12(ptrvec, num);
    printf("Total: %d\n", total);

    return 0;
}
