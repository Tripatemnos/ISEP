int vec_greater12(int* ptr, int num);
