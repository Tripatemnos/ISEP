int encrypt(char* ptr);
