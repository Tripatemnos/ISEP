#include <stdio.h>
#include "encrypt.h"
char word[] = "Hello angelina";
char * ptr1 = word;

int main(){
    printf("\nNot Encrypted: %s\n", ptr1);
    encrypt(ptr1);
    printf("\nEncrypted: %s\n", ptr1);
    return 0;
}
