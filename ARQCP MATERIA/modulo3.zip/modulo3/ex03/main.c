#include <stdio.h>
#include "str_copy_roman2.h"

char string1[] = "Hellu WorlUd!";
char string2[sizeof(string1)];
char * ptr1 = string1;
char * ptr2 = string2;

int main(){
    str_copy_roman2(ptr1, ptr2);
    printf("\nString 1: %s\n", ptr1);
    printf("\nString 2: %s\n", ptr2);
    return 0;
}

