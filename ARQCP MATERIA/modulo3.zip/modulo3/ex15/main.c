#include <stdio.h>
#include "sum_third_byte.h"

int main() {
    long array[] = {0x1122334455667788, 0xAABBCCDDEEFF0011, 0x2233445566778899};
    int length = sizeof(array) / sizeof(array[0]);

    int result = sum_third_byte(array, length);
    printf("Sum of third bytes: %d\n", result);

    return 0;
}
