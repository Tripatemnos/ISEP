#include <stdio.h>
#include "sort_without_reps.h"

int main() {
    short src_array[] = {5, 3, 2, 3, 1, 4, 2, 5, 6};
    short dest_array[9];
    int num = 9;

    int result = sort_without_reps(src_array, dest_array, num);

    printf("Sorted Array without Repetitions:\n");
    for (int i = 0; i < result; i++) {
        printf("%d ", dest_array[i]);
    }
    printf("\n");

    return 0;
}