#include <stdio.h>
#include "swap.h"
extern void swap(char* ptr1, char* ptr2, int num);

int main() {
    char ptr1[] = "Hello";
    char ptr2[] = "World";
    int num = 5; // Number of characters to swap

    printf("Before swap:\n");
    printf("ptr1: %s\n", ptr1);
    printf("ptr2: %s\n", ptr2);

    swap(ptr1, ptr2, num);

    printf("\nAfter swap:\n");
    printf("ptr1: %s\n", ptr1);
    printf("ptr2: %s\n");

    return 0;
}