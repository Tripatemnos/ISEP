#include <stdio.h>
#include "five_count.h"

char string[] = "atleast two 5's in here5";
char* ptr = string;

int main(){

    int counter = five_count(ptr);
    printf("\nThere are %d fives in the sentence\n", counter);
    return 0;

}
