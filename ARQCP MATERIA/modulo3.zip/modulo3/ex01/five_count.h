#ifndef FIVE_COUNT_H
#define FIVE_COUNT_H

extern char* ptr;  // Declare ptr as an external symbol

int five_count(char* ptr);

#endif // FIVE_COUNT_H




