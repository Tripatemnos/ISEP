#include <stdio.h>
#include "where_is.h" 
#include <stddef.h>

int main() {
	
    char myStr[] = "I can´t finish this work";
    char c = 'c';

    char* result = where_is(myStr, c);

    if (result != NULL) {
        printf("Character '%c' found at position: %ld\n", c, result - myStr);
    } else {
        printf("Character '%c' not found in the string.\n", c);
    }

    return 0;
}
