#include <stdio.h>
#include "sum_even.h"

int main() {
    int vec[] = {2, 2, 5, 7, 4};
    int result = sum_even(vec, 5);
    printf("%d\n", result);
    return 0;
}
