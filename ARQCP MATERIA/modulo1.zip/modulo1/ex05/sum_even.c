int sum_even(int *vec, int n) {
    int cont = 0;

    while (n != 0) {
        if (*vec % 2 == 0) {
            cont = cont + *vec;
        }
        vec++;
        n--;
    }

    return cont;
}
