#include <stdio.h>
#include "capitalize.h"

int main (){
	
	char str[256]=" Hello";
	
	printf("\n");
	
	printf("Before: ");
	printf("%s\n", str);
	
	printf("\n");
		 
	capitalize2(str);
		 
	printf("After: ");
	printf("%s\n", str);
	
	printf("\n");
	 
		return 0;
	}
	
