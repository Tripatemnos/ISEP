#include <stdio.h>

int is_whitespace(char c) {
    return (c == ' ' || c == '\t' || c == '\n' || c == '\r');
}

void format_string(char *str) {
	
    int capitalize = 1;

    while (*str) {
        if (is_whitespace(*str)) {
            capitalize = 1; 
        } else if (capitalize) {
            if (*str >= 'a' && *str <= 'z') {
                *str -= ('a' - 'A'); 
            }
            capitalize = 0; 
        } else {
            if (*str >= 'A' && *str <= 'Z') {
                *str += ('a' - 'A'); 
            }
        }

        str++;
    }
}
