#include <stdio.h>
#include <ctype.h>
#include "format_string.h"

int main() {
	
    char str[] = " the numBEr must be saved ";
    format_string(str);
    printf("%s\n", str);

    return 0;
}
