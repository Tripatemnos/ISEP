void get_array_statistics(int* vec, int n, int* min, int* max, float* avg) {
    int cont = 0;
    *min = *vec;  
    *max = *vec;
    int sizeVec = n;  

    if (n == 0) {
        
        *min = 0;
        *max = 0;
        *avg = 0;
        return;
    }

    while (n != 0) {
        
        if (*vec < *min) {
            *min = *vec;
        } else if (*vec > *max) {
            *max = *vec;
        }
        cont = cont + *vec;
        vec++;
        n--;
    }

    *avg = (float) cont / sizeVec;   
}
