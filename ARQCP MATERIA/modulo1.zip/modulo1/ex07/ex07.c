#include <stdio.h>
#include "array_statistics.h"

int main() {
    int vec[] = {1, 2, 3, 4, 5};
    int n = 5;
    int min, max;
    float avg;

    get_array_statistics(vec, n, &min, &max, &avg);

    printf("%d\n", min);
    printf("%d\n", max);
    printf("%f\n", avg);

    return 0;
}
