int is_space(char ch);
