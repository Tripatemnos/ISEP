#include "space.h"
int is_space(char ch) {
     if(ch == ' '){
		 return 1;
	 }else{
		 return 0;
	 }
		 
}
