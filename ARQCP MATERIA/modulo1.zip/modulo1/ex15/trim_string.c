#include "space.h"

void trim_string(char *str) {
    char *dest = str;
    int space = 0;        // 0 representa falso, 1 representa verdadeiro
    int wordStarted = 0;  // 0 representa falso, 1 representa verdadeiro

    while (*str) {
        if (is_space(*str)) {
            if (wordStarted) {
                space = 1;
            }
        } else {
            if (space && wordStarted) {
                *dest++ = ' ';
            }
            *dest++ = *str;
            space = 0;
            wordStarted = 1;
        }
        str++;
    }

    // Remove espaços finais, se houverem
    if (dest > str && is_space(*(dest - 1))) {
        dest--;
    }

    *dest = '\0';
}
