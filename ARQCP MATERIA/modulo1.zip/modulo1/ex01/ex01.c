#include <stdio.h>

int main() {
    int x = 5;
    int* ptr_x = &x;
    float y = *ptr_x + 3;

    printf("Value of x: %d\n", x);
    printf("Value of y: %f\n", y);
    printf("Address of x: %p\n", &x);
    printf("Address of y: %p\n", &y);
    printf("Address stored in ptr_x: %p\n", ptr_x);
    printf("Value pointed by ptr_x: %d\n", *ptr_x);
    // O endereço de vec tem a mesma saída que o valor de ptr_vec. Isto ocorre porque o endereço de vec retornará o local na memória onde o primeiro elemento do array "vec" está armazenado, da mesma forma que ptr_vec também retornará isso,
// porque corresponde a um ponteiro que aponta para o mesmo array "vec".

    int vec[] = {10, 20, 30, 40};
    int* ptr_vec = vec;
    int z = *ptr_vec;
    int h = *(ptr_vec + 3);

    printf("Value of z: %d\n", z);
    printf("Value of h: %d\n", h);
    printf("Address of vec: %p\n", ptr_vec);
    printf("Address of ptr_vec: %p\n", &ptr_vec);
    printf("Value of ptr_vec: %p\n", ptr_vec);
    printf("Value of vec: %d\n", *ptr_vec);
    printf("Value pointed by ptr_vec: %d\n", *ptr_vec);
    
    // No primeiro loop, temos uma variável i que iterará até alcançar o número de elementos no array e que imprime para cada elemento do array o endereço na memória onde está armazenado e o número correspondente.
// No segundo loop, a ideia é a mesma, a diferença é que o loop itera usando os endereços com ptr_vec. Portanto, o loop começa definindo o endereço de ptr_vec para o primeiro elemento de vec e terminará quando alcançar o endereço do último elemento em ptr_vec < vec + 4.
// No último loop, a ideia básica é a mesma, mas os endereços e valores serão impressos em ordem inversa. Assim, o código começará no último elemento do array em ptr_vec = vec + 3 e terminará quando ptr_vec alcançar o endereço do primeiro elemento de "vec", em ptr_vec >= vec.
// O ptr_vec++ é usado para avançar para o endereço do próximo elemento apresentado no array "vec". Ele faz isso avançando 4 bytes na memória, indo para o próximo elemento em vec.
// O ptr_vec-- é usado para retroceder ao endereço do elemento que aparece antes no array "vec".


    int i;
    for (i = 0; i < 4; i++) {
        printf("1: %p, %d\t", &vec[i], vec[i]);
    }
    printf("\n");
    for (ptr_vec = vec; ptr_vec < vec + 4; ptr_vec++) {
        printf("2: %p, %d\t", ptr_vec, *ptr_vec);
    }
    printf("\n");
    for (ptr_vec = vec + 3; ptr_vec >= vec; ptr_vec--) {
        printf("3: %p, %d\t", ptr_vec, *ptr_vec);
    }

    printf("\n");
    ptr_vec = vec;
    printf("4: %p, %d\n", ptr_vec, *ptr_vec);
    int a = *ptr_vec++;
    printf("5: %p, %d, %d\n", ptr_vec, *ptr_vec, a);
    ptr_vec = vec;
    a = (*ptr_vec)++;
    printf("6: %p, %d, %d\n", ptr_vec, *ptr_vec, a);
    ptr_vec = vec;
    a = *++ptr_vec;
    printf("7: %p, %d, %d\n", ptr_vec, *ptr_vec, a);
    ptr_vec = vec;
    a = ++*ptr_vec;
    printf("8: %p, %d, %d\n", ptr_vec, *ptr_vec, a);

    printf("\n");
    for (ptr_vec = vec; ptr_vec < vec + 4; ptr_vec++) {
        printf("9: %p, %d\t", ptr_vec, *ptr_vec);
    }
    // O printf número 4 apenas imprimirá o endereço do primeiro elemento de vec (ptr_vec) e o valor armazenado nesse local (*ptr_vec).
// O printf número 5, a declaração int a = *ptr_vec ocorrerá primeiro, dando à variável a o valor de *ptr_vec, e então ocorrerá ptr_vec++, o que resultará na impressão do endereço do segundo elemento do array (ptr_vec), o valor desse elemento (*ptr_vec) e depois imprimirá a, que ainda tem o valor do primeiro elemento do array.
// O printf número 6, a parte ptr_vec = vec definirá o endereço de ptr_vec para o local do primeiro elemento do array vec. Em seguida, a linha a = (*ptr_vec)++; fará com que a variável a seja definida com o valor correspondente a *ptr_vec e ptr_vec terá um valor adicionado ao endereço para o qual está apontando. Portanto, será impresso o endereço do primeiro elemento de vec (ptr_vec), em seguida, será impresso o valor desse elemento enquanto somando um a esse elemento (*ptr_vec) e depois será impresso a, que ainda tem o valor do primeiro elemento de vec (a).
// O printf número 7 primeiro definirá o valor de ptr_vec como o endereço do primeiro elemento do array vec (ptr_vec = vec;). Em seguida, definirá a como o valor do elemento na segunda posição do array, resultando em ptr_vec apontando para essa posição. Será impresso o endereço do segundo elemento do array (ptr_vec), depois o valor correspondente a esse local (*ptr_vec) e então será impresso a, que também armazena esse valor.
// O printf número 8 primeiro definirá o valor de ptr_vec como o endereço do primeiro elemento do array vec (ptr_vec = vec;). Em seguida, ocorrerá ++*ptr_vec, o que definirá o valor de *ptr_vec como 12, o que também afetará o valor de a para ser 12. Isso ocorre porque no printf 6, alteramos o valor do primeiro elemento de vec para 11, então agora, quando solicitado para incrementar 1, obtemos o valor 12 para *ptr_vec e a. Portanto, embora o valor de impressão do próprio endereço ainda seja o local do primeiro elemento do array (10), o valor em si de a e *ptr_vec será 12.
// O printf número 9 fará a mesma coisa que o printf número 2, a única diferença é que o printf 8 afetou o vec, de modo que seu primeiro elemento agora é 12, portanto, a única diferença na impressão é que o primeiro elemento será 12 em vez de 10, como acontece no printf 2.

    printf("\n");
    unsigned int d = 0xAABBCCDD;
    printf("10: %p, %x\t", &d, d);
    printf("\n");
    unsigned char* ptr_d = (unsigned char*)&d;
    unsigned char* p;
    for (p = ptr_d; p < ptr_d + sizeof(unsigned int); p++) {
        printf("11: %p, %x\t", p, (unsigned char)*p);
    }
    // O printf número 10 simplesmente imprimirá o endereço onde d está localizado em &d e, em seguida, imprimirá o seu valor d.
// O printf número 11, o loop iterará sobre cada byte da variável d, o que resultará na impressão do local do byte armazenado na variável p, que no loop começa com o valor de ptr_d e, em seguida, incrementa um byte do unsigned int de cada vez e armazena o local específico. Em seguida, para cada byte, é impresso o seu local por meio da variável p e o seu valor representado por *p.

    return 0;
}
