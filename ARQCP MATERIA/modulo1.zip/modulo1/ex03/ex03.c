#include <stdio.h>
#include "capitalize.h"

int main() {
	char str[] = "HellO";
	
	capitalize(str);
	printf("%s\n", str);
	
	
	return 0;
	
}
