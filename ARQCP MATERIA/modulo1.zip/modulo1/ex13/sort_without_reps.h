int sort_without_reps(short *src, int n, short *dest);
