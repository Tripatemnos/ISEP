#include <stdio.h>
#include "sort_without_reps.h"
#include "sort.h"



int main(){
short src[] = {3, 1, 2, 3, 1, 4, 5, 2}; 
    int n = sizeof(src) / sizeof(src[0]); 
    short dest[n]; 
    int count = sort_without_reps(src, n, dest);
    
    printf("Number of items placed in the second array: %d\n", count);
    printf("Content of the second array after eliminating duplicates and sorting: ");
    for (int i = 0; i < count; i++) {
        printf("%d ", dest[i]);
    }
    printf("\n");

    return 0;


}
