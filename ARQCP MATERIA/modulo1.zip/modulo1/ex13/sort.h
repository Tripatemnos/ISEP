void sort(short *dest, int n);
