#include "sort.h"

int sort_without_reps(short *src, int n, short *dest){
int sizeDest = 0;
    
    for (int i = 0; i < n; i++) {
        int number = *src;
        int inArray = 0;
        
        for (int j = 0; j < sizeDest; j++) {
            int number1 = dest[j];
            if (number1 == number) {
                inArray = 1;
                break;
            }
        }
        
        if (inArray == 0) {
            dest[sizeDest] = number;
            sizeDest++;
        }
        
        src++;
    }
    
    sort(dest, sizeDest);
    
    return sizeDest;


}
