int count_words(char *str);
