void frequencies(float *grades, int n, int *freq) {
    for (int i = 0; i <= 20; i++) {
        int cont = 0;
        for (int j = 0; j < n; j++) {
            if ((int) grades[j] == i) {
                cont++;
            }
        }
        *freq = cont;
        freq++; // Move o ponteiro de freq para a próxima posição no array freq
    }
}
