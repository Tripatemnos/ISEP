int sum_integer_bytes(unsigned int *p) {
    unsigned char *bytePtr = (unsigned char *)p;
    int sum = 0;

    
    for (int i = 0; i < sizeof(unsigned int); i++) {
        sum += *(bytePtr + i); 
    }

    return sum;
}
