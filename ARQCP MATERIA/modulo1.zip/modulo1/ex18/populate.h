void populate(unsigned char *vec, int num, unsigned char limit);
