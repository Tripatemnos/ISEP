int numSets = 0;

void inc_nsets() {
    numSets++;
}

