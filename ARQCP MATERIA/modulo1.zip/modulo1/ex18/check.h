int check(unsigned char x, unsigned char y, unsigned char z);
