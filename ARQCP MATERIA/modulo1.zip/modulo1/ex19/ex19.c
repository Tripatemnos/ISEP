#include <stdio.h>
#include "swap.h"

int main() {
    short vec1[] = {1, 2, 3, 4, 5};
    short vec2[] = {6, 7, 8, 9, 10};
    int size = sizeof(vec1) / sizeof(short);

    printf("Conteúdo original de vec1: ");
    for (int i = 0; i < size; i++) {
        printf("%d ", vec1[i]);
    }
    printf("\n");

    printf("Conteúdo original de vec2: ");
    for (int i = 0; i < size; i++) {
        printf("%d ", vec2[i]);
    }
    printf("\n");

    // Troca o conteúdo de vec1 e vec2
    swap(vec1, vec2, size);

    printf("Novo conteúdo de vec1 após a troca: ");
    for (int i = 0; i < size; i++) {
        printf("%d ", vec1[i]);
    }
    printf("\n");

    printf("Novo conteúdo de vec2 após a troca: ");
    for (int i = 0; i < size; i++) {
        printf("%d ", vec2[i]);
    }
    printf("\n");

    return 0;
}
