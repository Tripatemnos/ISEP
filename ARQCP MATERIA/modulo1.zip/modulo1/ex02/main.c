#include <stdio.h>

int main(){
	double dVar = 1,2345;
	int iVar = 123;
	char cVar = "A";
	
	double *doublePtr = &dVar;
	int *intPtr = &iVar;
	char *cVar = &cVar;
	
	printf("Double Variable:\n");
	printf("Adress: %p\n", (void*)doublePtr);
	printf("Value: %lf\n", *doublePtr);
	printf("Memory Size: %lu bytes\n\n", sizeof(doubleVar));
	
	printf("Integer Variable:\n");
    printf("Address: %p\n", (void *)intPtr);
    printf("Value: %d\n", *intPtr);
    printf("Memory Size: %lu bytes\n\n", sizeof(intVar));

    printf("Character Variable:\n");
    printf("Address: %p\n", (void *)charPtr);
    printf("Value: %c\n", *charPtr);
    printf("Memory Size: %lu bytes\n", sizeof(charVar));
		
		return 0;
	}
