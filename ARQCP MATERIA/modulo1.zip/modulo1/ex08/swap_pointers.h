void swap_pointers(char **x, char **y);
