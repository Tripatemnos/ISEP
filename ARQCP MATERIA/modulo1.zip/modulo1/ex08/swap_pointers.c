void swap_pointers(char **x, char **y) {
    char *tmp;
    tmp = *x;
    *x = *y;
    *y = tmp;
}
