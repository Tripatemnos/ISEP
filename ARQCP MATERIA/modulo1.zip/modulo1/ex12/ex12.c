#include <stdio.h>
#include "array_sort.h"

int main() {
	
    int Array[] = {23, 45, 2, 146, 1500};
    int n = sizeof(Array) / sizeof(Array[0]);
    
    printf("\n Given Array: ");
    
    for (int i = 0; i < n; i++) {
        printf("%d ", Array[i]);
    }

    array_sort(Array, n);
    
    printf("\n \n Sorted Array in ascending order: ");
    
    for (int i = 0; i < n; i++) {
        printf("%d ", Array[i]);
    }

    printf("\n \n");
    
    return 0;
}
