void array_sort(int *vec, int n) {
	
    int temp;
    int *ptr1, *ptr2;

    for (int i = 0; i < n - 1; i++) {
        ptr1 = vec;
        ptr2 = vec + 1;

        for (int j = 0; j < n - 1 - i; j++) {
            if (*ptr1 > *ptr2) {
                temp = *ptr1;
                *ptr1 = *ptr2;
                *ptr2 = temp;
            }
            ptr1++;
            ptr2++;
        }
    }
}
