#include <stdio.h>
#include "sum_odd.h"

int main() {
    int array[] = {7, 2, 3, 5, 6, 8, 9, 7}; 
    int result = sum_odd(&array[0]);

    printf("Sum of odd elements in the array: %d\n", result);

    return 0;
}
