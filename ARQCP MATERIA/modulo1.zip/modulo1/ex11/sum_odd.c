int sum_odd(int *p) {
    int numberElements = *p;
    p++;
    int sum = 0;

    for (int i = 1; i <= numberElements; i++) {
        int number = *p;
        if (number % 2 != 0) {
            sum = sum + number;
        }
        p++;
    }

    return sum;
}
