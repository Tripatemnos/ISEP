int sum_odd(int *p);
