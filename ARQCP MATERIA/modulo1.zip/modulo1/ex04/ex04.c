#include <stdio.h>
#include "copy_vec.h"

int main(){

	int vec1[] = {1,2,3,4,5,6,7,8,9,10};

	int length = sizeof(vec1)/sizeof(vec1[0]);
	int  vec2[length];

	copy_vec(vec1, vec2, length);
	
	printf("\n");
	
	printf("vec 1: ");
	for(int i = 0; i < length ; i++){
		printf("%d ", vec1[i]);
	}
	
	printf("\n \n");
	
	printf("vec 2: ");
	for(int i = 0; i < length ; i++){
		printf("%d ", vec2[i]);
	}
	printf("\n");
	printf("\n");

}
