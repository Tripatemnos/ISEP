#ifndef premiados_h
#define premiados_h
int premiados(unsigned int * viagens, int n, unsigned char * premio);
#endif
