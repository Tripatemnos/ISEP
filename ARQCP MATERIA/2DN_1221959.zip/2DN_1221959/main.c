#include <stdio.h>
#include "premiados.h"
#include "tempototal.h"

int main() {

    int n = 6;
    unsigned int viagens[6] = {0x34821929, 0x4C004A04, 0x7E894802, 0x914C0C85, 0xB9070AC3, 0xDF488686};
    unsigned char premio[6];

    int a = 0;
    int tempoViagenstotal = 0;

    for (int i = 0; i < n; i++) {
        a = tempo_total(viagens[i]);
        tempoViagenstotal = tempoViagenstotal + a;
    }

    int com_premio = premiados(viagens, n, premio);

    printf("Tempo total: %d\n", tempoViagenstotal);
    printf("Número de veículos com prêmio: %d\n", com_premio);

    printf("Veículos com prêmio: ");
    for (int i = 0; i < n; i++) {
            printf("Veiculos premiados %c\n ", premio[i]);
    }
    printf("\n");

    return 0;
}
