#ifndef tempo_total_h
#define tempo_total_h
int tempo_total(unsigned int viagem);
#endif
