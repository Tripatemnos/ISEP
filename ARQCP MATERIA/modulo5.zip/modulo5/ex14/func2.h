#ifndef FUNC2_H
#define FUNC2_H
int **new_matrix(int lines, int columns);
#endif 