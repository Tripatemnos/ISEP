int validar_pressao(unsigned int passador);
