#ifndef EXTRACT_TOKEN_H
#define EXTRACT_TOKEN_H
int extract_token(char* input, char* token, int* output);
#endif
