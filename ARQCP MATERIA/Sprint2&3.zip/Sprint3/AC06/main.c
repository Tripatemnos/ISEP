#include <stdio.h>
#include "extract_token.h"

int main() {
    char input[] = "sensor_id:8#type:atmospheric_temperature#value:21.60#unit:celsius#time:2470030";
    char token[] = "value:";
    int expected_output = 2160; // Substitua pelo valor esperado
    int output[1] = {0};

    int result = extract_token(input, token, output);

    if (result == 1 && output[0] == expected_output) {
        printf("1\n");
    } else {
        printf("0\n");
    }

    return 0;
}
