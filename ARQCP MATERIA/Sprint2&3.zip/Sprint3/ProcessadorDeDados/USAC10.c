#include <stdio.h>
#include <time.h>

#include "USAC07.h"
#include "USAC08_09.h"

void serialize(SensorConfig *sensor, FILE *nomeDoArquivo, int mediana){
    fprintf(nomeDoArquivo, "%d,%d,%s,%s,%d#\n",
    sensor->sensor_id, sensor->buffer->write, sensor->type, sensor->unit, mediana);
}
