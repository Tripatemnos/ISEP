typedef struct {
    int *array;
    int length;
    int read;
    int write;
} CircularBuffer;

CircularBuffer *createCircularBuffer(int length);
void insertValue(CircularBuffer *buffer, int value);
int readValue(CircularBuffer *buffer);
void freeBuffer(CircularBuffer *buffer);
