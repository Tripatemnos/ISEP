#include <stdio.h>
#include <stdlib.h>

#include "USAC07.h"
typedef struct {
    CircularBuffer *buffer;
    int sensor_id;
    int time;
    char type[50];
    char unit[50];
} SensorConfig;

int leitura_insercao(FILE *arquivoConfig, SensorConfig *config){
    if (arquivoConfig == NULL) {
        printf("Erro no ficheiro\n");
        return NULL;
    }
    float value_f;
	fscanf(arquivoConfig, "sensor_id:%d#type:%49[^#]#value:%f#unit:%49[^#]#time:%d\n",
		&(config->sensor_id), config->type, &value_f, config->unit, &(config->time));
	int value = (int) (value_f * 100);

    return value;
}
