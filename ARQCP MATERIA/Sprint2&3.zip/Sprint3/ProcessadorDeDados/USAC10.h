void serialize(SensorConfig *sensor, FILE *nomeDoArquivo, int mediana);
