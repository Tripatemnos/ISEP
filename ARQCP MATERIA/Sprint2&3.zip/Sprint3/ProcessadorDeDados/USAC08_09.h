typedef struct {
    CircularBuffer *buffer;
    int sensor_id;
    int time;
    char type[50];
    char unit[50];
} SensorConfig;

int leitura_insercao(FILE *arquivoConfig, SensorConfig *config);
