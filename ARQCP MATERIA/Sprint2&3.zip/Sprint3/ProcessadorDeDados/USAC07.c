#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>


typedef struct {
    int *array;
    int length;
    int read;
    int write;
} CircularBuffer;

// Função para criar e inicializar o buffer circular
CircularBuffer *createCircularBuffer(int length) {
    CircularBuffer *buffer = (CircularBuffer *)malloc(sizeof(CircularBuffer));

    if (buffer == NULL) {
        perror("Erro ao alocar memória para o buffer");
        exit(EXIT_FAILURE);
    }

    buffer->array = (int *)malloc(length * sizeof(int));

    if (buffer->array == NULL) {
        perror("Erro ao alocar memória para o array do buffer");
        free(buffer);
        exit(EXIT_FAILURE);
    }

    buffer->length = length;
    buffer->read = 0;
    buffer->write = 0;

    // teste para criar diretórios
    // struct stat st = {0};

    // if (stat("diretorio1", &st) == -1) {
    //    mkdir("diretorio1", 0700);
    //}

    // if (stat("diretorio2", &st) == -1) {
    //    mkdir("diretorio2", 0700);
    // }

    return buffer;
}

void insertValue(CircularBuffer *buffer, int value) {
    buffer->array[buffer->write] = value;
    buffer->write = (buffer->write + 1) % buffer->length;

    if (buffer->write == buffer->read)
        buffer->read = (buffer->read + 1) % buffer->length;

//    // Imprimir estado do array e ponteiros
//    printf("Estado do array: ");
//    for (int i = 0; i < buffer->length; ++i) {
//        printf("%d ", buffer->array[i]);
//    }
//    printf("\nRead: %d, Write: %d\n", buffer->read, buffer->write);
}

int readValue(CircularBuffer *buffer) {
    int value = buffer->array[buffer->read];
    buffer->read = (buffer->read + 1) % buffer->length;
    return value;
}

void freeBuffer(CircularBuffer *buffer) {
    free(buffer->array);
    free(buffer);
}
