#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "USAC07.h"
#include "USAC08_09.h"
#include "USAC05.h"
#include "USAC10.h"
int main(int argc, char **argv) {
	char *a = *(argv + 1);
	char *b = *(argv + 2);
	char *c = *(argv + 3);
	char *d = *(argv + 4);
	int num_sensores = 0;
	int num = atoi(d);
	//int num = 20;
	//char *a = "/dev/ttyS2";
	int id_max = 0;
	SensorConfig **sensores = (SensorConfig **)calloc(1, sizeof(SensorConfig*));
	int contador_leitura = 0;
	FILE *arquivoConfig = fopen(a, "r");
	printf("A ler valores...\n");
	do{
		SensorConfig *config = (SensorConfig *)malloc(sizeof(SensorConfig));
		if(config == NULL){
			printf("Erro na memória (sensor)\n");
			return 1;
		}
		config->buffer = createCircularBuffer(5);
		int value = leitura_insercao(arquivoConfig, config);
		if(config->sensor_id - 1 > id_max){
			id_max = config->sensor_id;
			sensores = realloc(sensores, id_max * sizeof(SensorConfig*));
			if(sensores == NULL){
				printf("Erro na memória (array)\n");
				return 1;
			}
		}
		//printf("sensor id: %d\n", config->sensor_id);
		SensorConfig *ptr = *(sensores + config->sensor_id -1) ;
		if(ptr != 0 && ptr->sensor_id == config->sensor_id){
			insertValue(ptr->buffer ,value);
			free(config);
		} else {
			insertValue(config->buffer, value);
			int id = config->sensor_id;
			*(sensores + id - 1) = config;
			num_sensores++;
		}
		contador_leitura++;
	} while(contador_leitura < num);
	printf("A fechar o ficheiro...\n");
	fclose(arquivoConfig);
	printf("Ficheiro fechado!\n");

	chdir("..");
	mkdir(c);
	time_t t;
	time(&t);
	struct tm* tm_info = localtime(&t);

	char nomeArquivo[50];
    sprintf(nomeArquivo, "%s/%04d%02d%02d%02d%02d%02d_sensors.txt",
            c, tm_info->tm_year + 1900, tm_info->tm_mon + 1, tm_info->tm_mday,
            tm_info->tm_hour, tm_info->tm_min, tm_info->tm_sec);

	FILE *arquivoOutput = fopen(nomeArquivo, "w");

    if (arquivoOutput == NULL) {
        perror("Erro ao criar o arquivo");
        return 1;
    }

	for(int i = 0; i < num_sensores; i++){
		SensorConfig *ptr = *(sensores + i);
		if(ptr != 0) {
			int write = ptr->buffer->write;
			int read = ptr->buffer->read;
			int n;
			if(write > read){
				n = write;
			} else {
				n = ptr->buffer->length;
			}
			int value = mediana(ptr->buffer->array, n);
			//printf("sensor_id: %d -- mediana: %d\n", ptr->sensor_id, value);
			serialize(ptr, arquivoOutput, value);
		}
	}
	fclose(arquivoOutput);
	printf("Arquivo criado com sucesso: %s\n", nomeArquivo);

	for (int i = 0; i < id_max; i++){
		SensorConfig *sensor = *(sensores + i);
		if (sensor != 0){
			freeBuffer(sensor->buffer);
			free(sensor);
		}
	}
	free(sensores);
	

	return 0;
}
