int mediana(int* vec, int num);
