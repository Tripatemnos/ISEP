void sort_array(int* ptr, int num);
