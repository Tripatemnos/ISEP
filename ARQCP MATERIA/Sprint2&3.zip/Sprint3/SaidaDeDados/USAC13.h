typedef struct {
    char type[50];
    int min;
    int max;
} Values;

void serialize(Values *values, FILE *output);
