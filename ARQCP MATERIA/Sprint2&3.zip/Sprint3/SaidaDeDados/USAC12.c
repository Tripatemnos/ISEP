#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <string.h>
#include <unistd.h>
#include <time.h>

#include "USAC13.h"

#define MAX_FILENAME_LENGTH 50

int main(int argc, char **argv) {
    char *a = *(argv + 1); // Diretorio Input
    char *b = *(argv + 2); // Diretorio Output
    char *c = *(argv + 3); // Periocidade

    int periocity = atoi(c) / 1000;
    
    // Salva o diretório atual
    char currentDirectory[256];
    if (getcwd(currentDirectory, sizeof(currentDirectory)) == NULL) {
        perror("getcwd");
        exit(EXIT_FAILURE);
    }

	Values **arr_values = (Values **)calloc(1, sizeof(Values *));
    if (arr_values == NULL) {
        printf("Erro ao alocar memória para o vetor\n");
        return 1;
    }

	// Constroi o comando com o diretório passado como parâmetro
	char command[1024];
	char lastFile[256] = "";  // Armazena o último arquivo lido
	snprintf(command, sizeof(command), "ls -1 ../%s | sort", a);
	
	// Abre um fluxo de leitura para a saída do comando
	FILE *lsOutput = popen(command, "r");
	if (lsOutput == NULL) {
		perror("popen");
		exit(EXIT_FAILURE);
	}
	
	printf("Leitura e escrita iniciadas...\n");
	// Lê os arquivos no diretório
	char buffer[256];
	while (fgets(buffer, sizeof(buffer), lsOutput) != NULL) {
		// Remove caracteres de nova linha
		buffer[strcspn(buffer, "\n")] = '\0';
		
		if (strcmp(buffer, lastFile) > 0){
			
			char filepath[256];
            snprintf(filepath, sizeof(filepath), "../%s/%s", a, buffer);
            
			FILE *input = fopen(filepath, "r");
			
			int num_types = 0;
			
			if (input != NULL) {
				char line[256];
				
				int sensor_id;
				int write_counter;
				char type[50];
				char unit[50];
				int mediana;
				while (fscanf(input, "%d,%d,%49[^,],%49[^,],%d#", &sensor_id, &write_counter, type, unit, &mediana) == 5) {
					
					Values *values = (Values *) calloc(1, sizeof(Values));
					if(values == NULL){
						printf("Erro ao alocar memória para os valores\n");
						return 1;
					}
					
					int flag = 0; 
					for(int i = 0; i < num_types; i++){
						Values *ptr = *(arr_values + i);
						if(ptr != 0 && strcmp(ptr->type, type) == 0){
							strcpy(ptr->type, type);
							if(ptr->min > mediana) {
								ptr->min = mediana;
							}
							if(ptr->max < mediana) {
								ptr->max = mediana;
							}
							flag = 1;
						}
					}
					if(flag == 0){
						num_types++;
						arr_values = (Values **) realloc(arr_values, num_types * sizeof(Values));
						if(arr_values == NULL){
							printf("Erro na memória (realocação array)\n");
							return 1;
						}
						strcpy(values->type, type);
						values->min = mediana;
						values->max = mediana;
						*(arr_values + num_types - 1) = values;
					} else {
						free(values);
					}			
				}
				
				fclose(input);
				
				chdir("..");
				mkdir(b);
				time_t t;
				time(&t);
				struct tm* tm_info = localtime(&t);

				char nomeArquivo[50];
				sprintf(nomeArquivo, "%s/%04d%02d%02d%02d%02d%02d_values.txt",
						b, tm_info->tm_year + 1900, tm_info->tm_mon + 1, tm_info->tm_mday,
						tm_info->tm_hour, tm_info->tm_min, tm_info->tm_sec);

				FILE *arquivoOutput = fopen(nomeArquivo, "w");

				if (arquivoOutput == NULL) {
					perror("Erro ao criar o arquivo");
					return 1;
				}

				for (int i = 0; i < num_types; i++) {
					Values *ptr = *(arr_values + i);
					if(ptr != 0){
						serialize(ptr, arquivoOutput);
					}
				}
				
				fclose(arquivoOutput);
				
				// Restaura o diretório original após emitir o output
				if (chdir(currentDirectory) != 0) {
					perror("chdir");
					exit(EXIT_FAILURE);
				}
			}
			strcpy(lastFile, buffer);  
		}
		sleep(periocity);
	}
	
	pclose(lsOutput);
	
	return 0;
}

