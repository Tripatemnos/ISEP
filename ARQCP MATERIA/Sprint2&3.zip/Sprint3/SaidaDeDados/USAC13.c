#include <stdio.h>

typedef struct {
    char type[50];
    int min;
    int max;
} Values;

void serialize(Values *values, FILE *output)
{   
	int minimo_aux = values->min;
	float minimo = (float) minimo_aux / 100;
	int maximo_aux = values->max;
	float maximo = (float) maximo_aux / 100;
    fprintf(output, "%s:\nmínimo:%f\nmáximo:%f\n\n",values->type, minimo, maximo);

}
