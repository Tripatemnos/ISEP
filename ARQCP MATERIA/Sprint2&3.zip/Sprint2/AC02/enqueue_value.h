#ifndef ENQUEUE_VALUE_H
#define ENQUEUE_VALUE_H
void enqueue_value(int* array, int length,int* read, int* write, int value);
#endif
