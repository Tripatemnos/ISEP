#include <stdio.h>
#include "enqueue_value.h"


int main() {
    int array[] = {50, 20, 10};
    int length = sizeof(array) / sizeof(array[0]);
    int read []= {0};
    int write[] = {0};
    int value = 40;

    printf("\nOriginal array: ");
    for (int i = 0; i < length; i++) {
        printf("%d ", array[i]);
    }
    printf("\n");

    enqueue_value(array, length, read, write, value);

    printf("New Array: ");
    for (int i = 0; i < length; i++) {
        printf("%d ", array[i]);
    }
    printf("\n");

    return 0;
}
