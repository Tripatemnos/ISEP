#ifndef SORT_ARRAY_H
#define SORT_ARRAY_H
void sort_array(int* vec, int num);
#endif
