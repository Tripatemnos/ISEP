#include <stdio.h>
#include "sort_array.h"

int main() {
    int array[] = {3,5,7,9,1};
    int num = sizeof(array) / sizeof(int);
    
    printf("Original array: ");
    for (int i = 0; i < num; ++i) {
        printf("%d ", array[i]);
    }
    printf("\n");

    sort_array(array, num);

    printf("Sorted array: ");
    for (int i = 0; i < num; ++i) {
        printf("%d ", array[i]);
    }
    printf("\n");

    return 0;
}

