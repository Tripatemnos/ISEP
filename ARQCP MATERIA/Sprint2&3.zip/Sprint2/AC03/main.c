#include <stdio.h>
#include "move_num_vec.h"


int main(){
	int array[] = {3,2,7,8,5};
	int length = sizeof(array) / sizeof(int);
	int write[]={0};
	int read[]={0};
	int num = 3;
	int vec[num];

	printf("Operation Result : %d\n",	move_num_vec(array, length, read, write, num, vec));

	return 0;
}
