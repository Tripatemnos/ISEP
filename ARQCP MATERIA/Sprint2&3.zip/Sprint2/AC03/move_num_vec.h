#ifndef MOVE_NUM_VEC_H
#define MOVE_NUM_VEC_H
int move_num_vec(int* array, int length, int *read,int *write, int num, int* vec);
#endif
