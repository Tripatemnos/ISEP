#include <stdio.h>
#include "mediana.h"
#include "sort_array.h"

int main() {
    int array[] = {50,20,10,70};
    int num = sizeof(array) / sizeof(int);
    
    printf("Original array: ");
    for (int i = 0; i < num; i++) {
        printf("%d ", array[i]);
    }
    printf("\n");

    sort_array(array, num);
    printf("Sorted Array :");
    for (int i = 0; i < num; i++) {
        printf("%d ", array[i]);
    }
    printf("\n");

    printf("Mediana : %d", mediana(array,num));

    printf("\n");

    return 0;
}

