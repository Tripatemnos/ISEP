#ifndef MEDIANA_H
#define MEDIANA_H
int mediana(int* vec, int num);
#endif
