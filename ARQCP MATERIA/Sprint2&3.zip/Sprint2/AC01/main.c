#include <stdio.h>
#include "extract_token.h"

int main() {
    char input[] = "sensor_id:8#type:atmospheric_temperature#value:21.60#unit:celsius#time:2470030";
    char token[] = "value:";
    int output[1] = {0}; 
   
    
    extract_token(input, token, output);
    
    for (int i = 0; i <1; i++) {
        printf("Result : %d \n", output[i]);
    }

    return 0;
}
