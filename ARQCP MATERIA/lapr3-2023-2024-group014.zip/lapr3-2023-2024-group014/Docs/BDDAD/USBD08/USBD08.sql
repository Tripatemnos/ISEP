SELECT FatorProducao.Designacao, COUNT(Operacao.FatorProducaoDesignacao) AS NumeroDeAplicacoes
FROM FatorProducao
JOIN Operacao ON Operacao.FatorProducaoDesignacao = FatorProducao.Designacao
WHERE TO_DATE(Operacao.CulturaDataInicio, 'DD/MM/YYYY') BETWEEN TO_DATE('02/05/2016', 'DD/MM/YYYY') AND TO_DATE('05/09/2023', 'DD/MM/YYYY')
GROUP BY FatorProducao.Designacao
HAVING COUNT(Operacao.FatorProducaoDesignacao) = (
    SELECT MAX(Contagem)
    FROM (
        SELECT COUNT(FatorProducaoDesignacao) AS Contagem
        FROM Operacao
        WHERE TO_DATE(CulturaDataInicio, 'DD/MM/YYYY') BETWEEN TO_DATE('02/05/2016', 'DD/MM/YYYY') AND TO_DATE('05/09/2023', 'DD/MM/YYYY')
        GROUP BY FatorProducaoDesignacao
    ) Subquery
);
