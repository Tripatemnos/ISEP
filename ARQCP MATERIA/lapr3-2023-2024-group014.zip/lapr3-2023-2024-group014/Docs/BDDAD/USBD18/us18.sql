--CREATE FUNCTION FOR LISTING OPERATIONS ON A CERTAIN PARCEL ON A SPECIFIC TIME PERIOD
CREATE OR REPLACE FUNCTION obter_lista_operacoes(
    p_parcela_id Operacao.ParcelaId%type,
    p_data_inicio Operacao.CulturaDataInicio%type,
    p_data_fim Operacao.CulturaDataInicio%type
)
RETURN SYS_REFCURSOR
AS
    operacoes_cursor SYS_REFCURSOR;
BEGIN
    OPEN operacoes_cursor FOR
        SELECT
            Operacao.ParcelaId,
            Operacao.TipoOperacaoDesignacao,
            Operacao.CulturaCulturaDesignacao,
            Operacao.CulturaDataInicio,
            Operacao.Quantidade,
            Operacao.UnidadeDesignacao,
            Operacao.FatorProducaoDesignacao
        FROM
            Operacao
        WHERE
            Operacao.ParcelaId = p_parcela_id
            AND TO_DATE(Operacao.CulturaDataInicio, 'DD/MM/YYYY') BETWEEN TO_DATE(p_data_inicio, 'DD/MM/YYYY') AND TO_DATE(p_data_fim, 'DD/MM/YYYY')
        ORDER BY
            Operacao.TipoOperacaoDesignacao, Operacao.CulturaDataInicio;

    RETURN operacoes_cursor;
END;
/







--TEST GETTING INFORMATION FROM THE CURSOR
DECLARE
    v_cursor SYS_REFCURSOR;
    v_tipo_operacao Operacao.TipoOperacaoDesignacao%TYPE;
    v_parcela_id Operacao.ParcelaId%TYPE;
    v_cultura_designacao Operacao.CulturaCulturaDesignacao%TYPE;
    v_data_inicio Operacao.CulturaDataInicio%TYPE;
    v_quantidade Operacao.Quantidade%TYPE;
    v_unidade_designacao Operacao.UnidadeDesignacao%TYPE;
    v_fator_producao_designacao Operacao.FatorProducaoDesignacao%TYPE;
    v_prev_tipo_operacao Operacao.TipoOperacaoDesignacao%TYPE := NULL;
    v_rows_found BOOLEAN := FALSE;

BEGIN
    -- Call the function with specific values
    v_cursor := obter_lista_operacoes(p_parcela_id => 104, p_data_inicio => '20/01/2019', p_data_fim => '14/03/2021');

    -- Fetch results
    LOOP
        FETCH v_cursor INTO v_parcela_id, v_tipo_operacao, v_cultura_designacao, v_data_inicio, v_quantidade, v_unidade_designacao, v_fator_producao_designacao;

        -- Check if any rows are fetched
        EXIT WHEN v_cursor%NOTFOUND;

        -- Rows are fetched, set the flag to true
        v_rows_found := TRUE;

        -- Print TipoOperacaoDesignacao only if it's a new type
        IF v_prev_tipo_operacao IS NULL OR v_tipo_operacao != v_prev_tipo_operacao THEN
            DBMS_OUTPUT.PUT_LINE('Tipo Operacao: ' || v_tipo_operacao);
        END IF;

        -- Print other details for each operation
        DBMS_OUTPUT.PUT_LINE('  Parcela Id: ' || v_parcela_id);
        DBMS_OUTPUT.PUT_LINE('  Cultura Designacao: ' || v_cultura_designacao);
        DBMS_OUTPUT.PUT_LINE('  Data Inicio: ' || v_data_inicio);
        DBMS_OUTPUT.PUT_LINE('  Quantidade: ' || v_quantidade);
        DBMS_OUTPUT.PUT_LINE('  Unidade Designacao: ' || v_unidade_designacao);
        IF v_fator_producao_designacao IS NOT NULL THEN
            DBMS_OUTPUT.PUT_LINE('  Fator Producao Designacao: ' || v_fator_producao_designacao);
        END IF;

        -- Update the previous TipoOperacaoDesignacao
        v_prev_tipo_operacao := v_tipo_operacao;

        DBMS_OUTPUT.PUT_LINE(CHR(10));
    END LOOP;

    -- Check if no rows were fetched
    IF NOT v_rows_found THEN
        DBMS_OUTPUT.PUT_LINE('Parcela não encontrada no intervalo de tempo especificado.');
    END IF;

    -- Close the cursor
    CLOSE v_cursor;
END;
/

