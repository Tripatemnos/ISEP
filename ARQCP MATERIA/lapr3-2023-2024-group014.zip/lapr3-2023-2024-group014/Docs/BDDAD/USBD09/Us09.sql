SELECT FatorProducao.Designacao, COUNT(Operacao.FatorProducaoDesignacao) AS NumeroDeAplicacoes
FROM FatorProducao
JOIN Operacao ON Operacao.FatorProducaoDesignacao = FatorProducao.Designacao
WHERE TO_DATE(Operacao.CulturaDataInicio, 'DD/MM/YYYY') BETWEEN TO_DATE('02/05/2021', 'DD/MM/YYYY') AND TO_DATE('05/09/2022', 'DD/MM/YYYY')
GROUP BY FatorProducao.Designacao;
