--Create 1
CREATE OR REPLACE PROCEDURE AdicionarTipoOperacao(pTipoOperacao IN VARCHAR2, pModo IN VARCHAR2) AS
BEGIN
  INSERT INTO TipoOperacao (TipoOperacao, Modo) VALUES (pTipoOperacao, pModo);
END AdicionarTipoOperacao;
/
--Create 2
CREATE OR REPLACE PROCEDURE AdicionarOperacaoMonda(
  pOperacaoId IN NUMBER,
  pParcelaId IN NUMBER,
  pTipoOperacaoDesignacao IN VARCHAR2,
  pCulturaCulturaDesignacao IN VARCHAR2,
  pCulturaDataInicio IN VARCHAR2,
  pQuantidade IN NUMBER,
  pUnidadeDesignacao IN VARCHAR2,
  pFatorProducaoDesignacao IN VARCHAR2
) AS
BEGIN
  IF pFatorProducaoDesignacao IS NULL THEN
        DBMS_OUTPUT.PUT_LINE('Erro: O valor de pFatorProducaoDesignacao não pode ser nulo para este tipo de operação.');
        RETURN;
      END IF;
  -- Verificar se a área da operação é superior à área da parcela
  SELECT Parcela.UnidadeQuantidade INTO vParcelaArea
  FROM Parcela
  WHERE Parcela.ExploracaoAgricolaId = pParcelaId
        AND Parcela.UnidadeDesignacao = pUnidadeDesignacao;

  -- Verificar se a quantidade é maior que a quantidade disponível na parcela
  IF pQuantidade > vParcelaArea THEN
    DBMS_OUTPUT.PUT_LINE('Erro: A quantidade da operação é superior à quantidade disponível na parcela.');
    RETURN;
  END IF;

  -- Verificar se a CulturaCulturaDesignacao existe na ParcelaId
  SELECT COUNT(*) INTO vVeracidade
  FROM EdificioAgricola
  WHERE EdificioAgricola.ExploracaoId = pParcelaId
    AND EdificioAgricola.DesignacaoEdificio = pCulturaCulturaDesignacao;

  IF vVeracidade = 0 THEN
    DBMS_OUTPUT.PUT_LINE('Erro: A CulturaCulturaDesignacao não existe na ParcelaId.');
    RETURN;
  END IF;

  -- Adicionar a operação
  INSERT INTO Operacao (
    OperacaoId,
    ParcelaId,
    TipoOperacaoDesignacao,
    CulturaCulturaDesignacao,
    CulturaDataInicio,
    Quantidade,
    UnidadeDesignacao,
    FatorProducaoDesignacao
  ) VALUES (
    pOperacaoId,
    pParcelaId,
    pTipoOperacaoDesignacao,
    pCulturaCulturaDesignacao,
    pCulturaDataInicio,
    pQuantidade,
    pUnidadeDesignacao,
    pFatorProducaoDesignacao
  );
END AdicionarOperacaoMonda;

/

--TESTE create 1

DECLARE
  vTipoOperacao VARCHAR2(255) := 'Monda';
  vModo VARCHAR2(255) := 'ModoMonda';
BEGIN
  AdicionarTipoOperacao(vTipoOperacao, vModo);
  COMMIT; -- Confirma as alterações no banco de dados
  DBMS_OUTPUT.PUT_LINE('Stored procedure AdicionarTipoOperacao executada com sucesso.');
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK; -- Desfaz as alterações em caso de erro
    DBMS_OUTPUT.PUT_LINE('Erro ao executar a stored procedure: ' || SQLERRM);
END;

/
--Teste para o create 2
DECLARE
  vOperacaoId NUMBER := 1557;
  vParcelaId NUMBER := 104;
  vTipoOperacaoDesignacao VARCHAR2(255) := 'Monda';
  vCulturaCulturaDesignacao VARCHAR2(255) := 'Cultura1';
  vCulturaDataInicio VARCHAR2(255) := '01/01/2023';
  vQuantidade FLOAT := 750;
  vUnidadeDesignacao VARCHAR2(255) := 'kg';
  vFatorProducaoDesignacao VARCHAR2(255) := 'Patentkali';
BEGIN
  AdicionarOperacaoMonda(
    vOperacaoId,
    vParcelaId,
    vTipoOperacaoDesignacao,
    vCulturaCulturaDesignacao,
    vCulturaDataInicio,
    vQuantidade,
    vUnidadeDesignacao,
    vFatorProducaoDesignacao
  );
  COMMIT; -- Confirma as alterações no banco de dados
  DBMS_OUTPUT.PUT_LINE('Stored procedure AdicionarOperacaoMonda executada com sucesso.');
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK; -- Desfaz as alterações em caso de erro
    DBMS_OUTPUT.PUT_LINE('Erro ao executar a stored procedure: ' || SQLERRM);
END;
/
