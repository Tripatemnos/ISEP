--Create 1
CREATE OR REPLACE PROCEDURE AdicionarTipoOperacao(pTipoOperacao IN VARCHAR2, pModo IN VARCHAR2) AS
BEGIN
  INSERT INTO TipoOperacao (TipoOperacao, Modo) VALUES (pTipoOperacao, pModo);
END AdicionarTipoOperacao;
/



CREATE OR REPLACE PROCEDURE AdicionarOperacaoAplicacaoFatorProducao(
  pOperacaoId Operacao.OperacaoId%type,
  pParcelaId Operacao.ParcelaId%type,
  pTipoOperacaoDesignacao Operacao.TipoOperacaoDesignacao%type,
  pCulturaCulturaDesignacao Operacao.CulturaCulturaDesignacao%type,
  pCulturaDataInicio Operacao.CulturaDataInicio%type,
  pQuantidade Operacao.Quantidade%type,
  pUnidadeDesignacao Operacao.UnidadeDesignacao%type,
  pFatorProducaoDesignacao Operacao.FatorProducaoDesignacao%type
) AS
vParcelaArea Parcela.UnidadeQuantidade%TYPE;
vVeracidade INT;

BEGIN
     IF pFatorProducaoDesignacao IS NULL THEN
        DBMS_OUTPUT.PUT_LINE('Erro: O valor de pFatorProducaoDesignacao não pode ser nulo para este tipo de operação.');
        RETURN;
      END IF;
  -- Verificar se a área da operação é superior à área da parcela
  SELECT Parcela.UnidadeQuantidade INTO vParcelaArea
  FROM Parcela
  WHERE Parcela.ExploracaoAgricolaId = pParcelaId
        AND Parcela.UnidadeDesignacao = pUnidadeDesignacao;

  -- Verificar se a quantidade é maior que a quantidade disponível na parcela
  IF pQuantidade > vParcelaArea THEN
    DBMS_OUTPUT.PUT_LINE('Erro: A quantidade da operação é superior à quantidade disponível na parcela.');
    RETURN;
  END IF;

  -- Verificar se a CulturaCulturaDesignacao existe na ParcelaId
  SELECT COUNT(*) INTO vVeracidade
  FROM EdificioAgricola
  WHERE EdificioAgricola.ExploracaoId = pParcelaId
    AND EdificioAgricola.DesignacaoEdificio = pCulturaCulturaDesignacao;

  IF vVeracidade = 0 THEN
    DBMS_OUTPUT.PUT_LINE('Erro: A CulturaCulturaDesignacao não existe na ParcelaId.');
    RETURN;
  END IF;

  -- Adicionar a operação
  INSERT INTO Operacao (
    OperacaoId,
    ParcelaId,
    TipoOperacaoDesignacao,
    CulturaCulturaDesignacao,
    CulturaDataInicio,
    Quantidade,
    UnidadeDesignacao,
    FatorProducaoDesignacao
  ) VALUES (
    pOperacaoId,
    pParcelaId,
    pTipoOperacaoDesignacao,
    pCulturaCulturaDesignacao,
    pCulturaDataInicio,
    pQuantidade,
    pUnidadeDesignacao,
    pFatorProducaoDesignacao
  );

  DBMS_OUTPUT.PUT_LINE('Operação registrada com sucesso.');
END AdicionarOperacaoAplicacaoFatorProducao;
/


--TESTE create 1

DECLARE
  vTipoOperacao VARCHAR2(255) := 'Aplicação fungicida';
  vModo VARCHAR2(255) := '';
BEGIN
  AdicionarTipoOperacao(vTipoOperacao, vModo);
  COMMIT; -- Confirma as alterações no banco de dados
  DBMS_OUTPUT.PUT_LINE('Stored procedure AdicionarTipoOperacao executada com sucesso.');
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK; -- Desfaz as alterações em caso de erro
    DBMS_OUTPUT.PUT_LINE('Erro ao executar a stored procedure: ' || SQLERRM);
END;
/





-- Teste 1: Inserção bem-sucedida
DECLARE
  vOperacaoId NUMBER := 15677;
  vParcelaId NUMBER := 104;
  vTipoOperacaoDesignacao VARCHAR2(50) := 'Aplicação fungicida';
  vCulturaCulturaDesignacao VARCHAR2(50) := 'Lameiro da ponte';
  vCulturaDataInicio VARCHAR2(10) := '2023-01-01';
  vQuantidade NUMBER := 0.1;
  vUnidadeDesignacao VARCHAR2(20) := 'ha';
  vFatorProducaoDesignacao VARCHAR2(50) := 'EPSO Microtop';

BEGIN
  AdicionarOperacaoAplicacaoFatorProducao(
    vOperacaoId,
    vParcelaId,
    vTipoOperacaoDesignacao,
    vCulturaCulturaDesignacao,
    vCulturaDataInicio,
    vQuantidade,
    vUnidadeDesignacao,
    vFatorProducaoDesignacao
  );
END;
/


-- Teste 2: Tentativa de inserção com quantidade maior que a disponível na parcela
DECLARE
  vOperacaoId NUMBER := 15678;
  vParcelaId NUMBER := 104;
  vTipoOperacaoDesignacao VARCHAR2(50) := 'Aplicação fungicida';
  vCulturaCulturaDesignacao VARCHAR2(50) := 'Lameiro da ponte';
  vCulturaDataInicio VARCHAR2(10) := '2023-02-01';
  vQuantidade NUMBER := 10; -- Quantidade maior que a disponível na parcela
  vUnidadeDesignacao VARCHAR2(20) := 'ha';
  vFatorProducaoDesignacao VARCHAR2(50) := 'Calda Bordalesa ASCENZA';

BEGIN
  AdicionarOperacaoAplicacaoFatorProducao(
    vOperacaoId,
    vParcelaId,
    vTipoOperacaoDesignacao,
    vCulturaCulturaDesignacao,
    vCulturaDataInicio,
    vQuantidade,
    vUnidadeDesignacao,
    vFatorProducaoDesignacao
  );
END;
/


--Test incoerencia entre parcelaID e CulturaDesignacao
DECLARE
  vOperacaoId NUMBER := 15679;
  vParcelaId NUMBER := 104;
  vTipoOperacaoDesignacao VARCHAR2(50) := 'Aplicação fungicida';
  vCulturaCulturaDesignacao VARCHAR2(50) := 'Cultura1';
  vCulturaDataInicio VARCHAR2(10) := '2023-02-01';
  vQuantidade NUMBER := 0.1; 
  vUnidadeDesignacao VARCHAR2(20) := 'ha';
  vFatorProducaoDesignacao VARCHAR2(50) := 'Calda Bordalesa ASCENZA';

BEGIN
  AdicionarOperacaoAplicacaoFatorProducao(
    vOperacaoId,
    vParcelaId,
    vTipoOperacaoDesignacao,
    vCulturaCulturaDesignacao,
    vCulturaDataInicio,
    vQuantidade,
    vUnidadeDesignacao,
    vFatorProducaoDesignacao
  );
END;
/



-- Teste 4: Fator de producao null
DECLARE
  vOperacaoId NUMBER := 15680;
  vParcelaId NUMBER := 104;
  vTipoOperacaoDesignacao VARCHAR2(50) := 'Aplicação fungicida';
  vCulturaCulturaDesignacao VARCHAR2(50) := 'Lameiro da ponte';
  vCulturaDataInicio VARCHAR2(10) := '2023-01-01';
  vQuantidade NUMBER := 0.1;
  vUnidadeDesignacao VARCHAR2(20) := 'ha';
  vFatorProducaoDesignacao VARCHAR2(50) := '';

BEGIN
  AdicionarOperacaoAplicacaoFatorProducao(
    vOperacaoId,
    vParcelaId,
    vTipoOperacaoDesignacao,
    vCulturaCulturaDesignacao,
    vCulturaDataInicio,
    vQuantidade,
    vUnidadeDesignacao,
    vFatorProducaoDesignacao
  );
END;
/