SELECT Operacao.TipoOperacaoDesignacao AS NomeDaOperacao, COUNT(*) AS NumeroDeOperacoes
FROM Operacao
WHERE ParcelaId = 104
AND TO_DATE(CulturaDataInicio, 'DD/MM/YYYY') BETWEEN TO_DATE('24/08/2021', 'DD/MM/YYYY') AND TO_DATE('11/09/2022', 'DD/MM/YYYY')
GROUP BY Operacao.TipoOperacaoDesignacao;