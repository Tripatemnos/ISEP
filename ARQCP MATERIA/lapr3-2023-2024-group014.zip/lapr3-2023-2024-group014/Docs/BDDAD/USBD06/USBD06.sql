SELECT 
    ParcelaId,
    FatorProducaoDesignacao,
    COUNT(*) AS NumeroDeFatores
FROM 
    Operacao
WHERE 
   TO_DATE(CulturaDataInicio, 'DD/MM/YYYY') BETWEEN TO_DATE('24/08/2021', 'DD/MM/YYYY') AND TO_DATE('05/09/2022', 'DD/MM/YYYY')
AND 
	ParcelaId = 104
AND 
	FatorProducaoDesignacao IS NOT NULL
GROUP BY 
    ParcelaId, FatorProducaoDesignacao;