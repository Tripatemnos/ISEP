SELECT 
    Operacao.ParcelaId,
    Operacao.CulturaCulturaDesignacao,
    SUM(CASE WHEN Operacao.TipoOperacaoDesignacao = 'Colheita' THEN Operacao.Quantidade ELSE 0 END) AS TotalQuantidade
FROM
    Operacao
WHERE
    TO_DATE(CulturaDataInicio, 'DD/MM/YYYY') BETWEEN TO_DATE('06/10/2016', 'DD/MM/YYYY') AND TO_DATE('12/01/2023', 'DD/MM/YYYY')
AND
    ParcelaId = 106
GROUP BY
    Operacao.ParcelaId, Operacao.CulturaCulturaDesignacao;