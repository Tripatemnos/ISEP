WITH OperacoesRegaParcelas AS (
    SELECT
        Operacao.ParcelaId,
        COUNT(*) AS TotalOperacoesRega
    FROM
        Operacao
    WHERE
        TO_DATE(CulturaDataInicio, 'DD/MM/YYYY') BETWEEN TO_DATE('06/10/2016', 'DD/MM/YYYY') AND TO_DATE('12/01/2023', 'DD/MM/YYYY')
        AND TipoOperacaoDesignacao = 'Rega'
    GROUP BY
        Operacao.ParcelaId
)

SELECT
    ParcelaId,
    MAX(TotalOperacoesRega) AS MaxTotalOperacoesRega
FROM OperacoesRegaParcelas
GROUP BY ParcelaId
HAVING MAX(TotalOperacoesRega) = (SELECT MAX(TotalOperacoesRega) FROM OperacoesRegaParcelas);
