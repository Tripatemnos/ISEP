void sort_array(int* vec, int num);
