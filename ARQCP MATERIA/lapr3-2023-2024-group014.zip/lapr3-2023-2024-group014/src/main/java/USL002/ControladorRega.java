package USL002;

import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class ControladorRega {
    private static final List<String> horasDeRega = new ArrayList<>();
    private static final List<Rega> planoRega = new ArrayList<>();

    public static void carregarInstrucoes(String arquivoInstrucoes) throws IOException, ParseException {
        BufferedReader br = new BufferedReader(new FileReader(arquivoInstrucoes));
        String linha;
        boolean primeiraLinha = true;

        while ((linha = br.readLine()) != null) {
            if (primeiraLinha) {
                String[] horas = linha.split(", ");
                horasDeRega.addAll(Arrays.asList(horas));
                primeiraLinha = false;
            } else {
                String[] partes = linha.split(",");
                String parcela = partes[0].trim();
                int duracao = Integer.parseInt(partes[1].trim());
                String regularidade = partes[2].trim();
                Rega rega = new Rega(parcela, duracao, regularidade);
                planoRega.add(rega);
            }
        }

        br.close();
    }


    public static void main(String[] args) throws IOException, ParseException {
        Scanner scanner = new Scanner(System.in);
        System.out.println("De qual arquivo pretende ler as instruçoes?");
        String arquivo = scanner.nextLine();
        carregarInstrucoes(arquivo);

        boolean conjuncao = gerarCSV("plano.csv");
        if (!conjuncao) {
            String arquivoCSV = "plano.csv";
            String linha = "";
            boolean primeiraLinha = true;
            List<RegaContr> controladorRega = new ArrayList<>();
            try (BufferedReader reader = new BufferedReader(new FileReader(arquivoCSV))) {
                while ((linha = reader.readLine()) != null) {
                    if (primeiraLinha) {
                        primeiraLinha = false;
                        continue; // Ignorar a primeira linha
                    }
                    RegaContr rega = new RegaContr(Integer.parseInt(linha.split("/")[0]), linha.split(",")[1], Integer.parseInt(linha.split(",")[2]), linha.split(",")[3], linha.split(",")[4]);
                    controladorRega.add(rega);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            System.out.println("Por favor, insira a data e hora desejadas (formato: dd HH:mm): ");
            String dataHoraString = scanner.nextLine();


            //Separacao da String recebida entre horas, minutos e dia
            StringBuilder output = new StringBuilder();

            for (char c : dataHoraString.toCharArray()) {
                if (c != ' ') {
                    output.append(c);
                } else {
                    break; // Se encontrarmos um espaço, paramos o loop
                }
            }

            int dia = Integer.parseInt(output.toString());
            int espacoIndex = dataHoraString.indexOf(' ');

            String horaMinutos = null;

            if (espacoIndex != -1 && espacoIndex + 1 < dataHoraString.length()) {
                horaMinutos = dataHoraString.substring(espacoIndex + 1);

            }
            int contador = 0;
            for (int i = 0; i < controladorRega.size(); i++) {
                if (dia == controladorRega.get(i).getDia() && verificarSeEstaEntre(controladorRega.get(i).getHoraInicio(), controladorRega.get(i).getHoraFim(), horaMinutos)) {
                    int diferenca = calcularDiferencaEmMinutos(horaMinutos, controladorRega.get(i).getHoraFim());
                    if (diferenca > 0) {
                        System.out.println("Setor a ser regado: " + controladorRega.get(i).getSetor() + "; Tempo para terminar: " + diferenca);
                        contador++;
                    }


                }

            }
            if (contador == 0) {
                System.out.println("Não está a ser regado nenhum setor no momento!");
            }
        }
    }

    public static int calcularDiferencaEmMinutos(String hora1, String hora2) {
        try {
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("HH:mm");
            java.util.Date date1 = sdf.parse(hora1);
            java.util.Date date2 = sdf.parse(hora2);

            // Calcula a diferença em milissegundos entre as duas horas
            long diferencaEmMilissegundos = date2.getTime() - date1.getTime();

            // Converte a diferença de milissegundos para minutos
            int diferencaEmMinutos = (int) (diferencaEmMilissegundos / (60 * 1000));
            return diferencaEmMinutos;
        } catch (java.text.ParseException e) {
            e.printStackTrace();
            return -1; // Retorna -1 em caso de erro de formatação
        }
    }

    //Verifica se uma hora esta entre outras duas
    public static boolean verificarSeEstaEntre(String horaInicio, String horaFim, String outraHora) {
        try {
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("HH:mm");
            java.util.Date horaInicioDate = sdf.parse(horaInicio);
            java.util.Date horaFimDate = sdf.parse(horaFim);
            java.util.Date outraHoraDate = sdf.parse(outraHora);

            // Verifica se a outraHora está entre horaInicio e horaFim
            return (outraHoraDate.equals(horaInicioDate) || outraHoraDate.after(horaInicioDate)) &&
                    (outraHoraDate.equals(horaFimDate) || outraHoraDate.before(horaFimDate));
        } catch (java.text.ParseException e) {
            e.printStackTrace();
            return false;
        }

    }


    public static String encontrarHoraMaisProxima(String horasEspecificas, String minutosEspecificos) {
        int menorDiferenca = Integer.MAX_VALUE;
        String horaMaisProxima = null;

        // Converter horasEspecificas e minutosEspecificos para minutos totais
        int minutosTotaisEspecificos = Integer.parseInt(horasEspecificas) * 60 + Integer.parseInt(minutosEspecificos);

        // Iterar sobre a lista de horasDeRega
        for (String hora : horasDeRega) {
            // Converter hora em minutos totais
            int minutosTotaisRega = Integer.parseInt(hora.split(":")[0]) * 60 + Integer.parseInt(hora.split(":")[1]);

            // Calcular a diferença em minutos
            int diferenca = Math.abs(minutosTotaisEspecificos - minutosTotaisRega);

            // Verificar se esta é a menor diferença até agora
            if (diferenca < menorDiferenca) {
                menorDiferenca = diferenca;
                horaMaisProxima = hora;
            }
        }

        return horaMaisProxima;
    }

    private static List<Rega> setoresDia(String dia) {
        List<Rega> RegaDia = new ArrayList<>();
        for (int i = 0; i < planoRega.size(); i++) {
            if (planoRega.get(i).getRegularidade().equals("T")) {
                RegaDia.add(planoRega.get(i));
            } else if (planoRega.get(i).getRegularidade().equals("I") && Integer.parseInt(dia) % 2 != 0) {
                RegaDia.add(planoRega.get(i));
            } else if (planoRega.get(i).getRegularidade().equals("P") && Integer.parseInt(dia) % 2 == 0) {
                RegaDia.add(planoRega.get(i));
            } else if (planoRega.get(i).getRegularidade().equals("3") && Integer.parseInt(dia) % 3 == 0) {
                RegaDia.add(planoRega.get(i));
            }
        }
        return RegaDia;
    }

    public static boolean gerarCSV(String arquivoSaida) throws IOException, ParseException {
        List<String> textFile = new ArrayList<>();

        try (PrintWriter writer = new PrintWriter(new FileWriter(arquivoSaida))) {
            textFile.add("Dia,Sector,Duração,Início,Final");
            List<String> horasFinais = new ArrayList<>(); //Lista que verifica se existe conjuncao de horarios
            for (int dia = 1; dia <= 30; dia++) {
                String dataString = String.format("%02d/11/2023", dia);

                List<Rega> regasDia = setoresDia(String.valueOf(dia));
                for (int i = 0; i < horasDeRega.size(); i++) {
                    String inicio = horasDeRega.get(i);
                    String finalHora = null;


                    for (Rega rega : regasDia) {

                        finalHora = adicionarMinutos(inicio, rega.getDuracao());


                        String linha = String.format("%s,%s,%d,%s,%s",
                                dataString, rega.getParcela(), rega.getDuracao(), inicio, finalHora);

                        textFile.add(linha);
                        inicio = finalHora;
                    }
                    horasFinais.add(finalHora);

                }
            }
            boolean conjuncao = verificarConjuncaoHorarios(horasFinais);
            if (conjuncao) {
                writer.flush();

                writer.println("Plano impossível de realizar");
                System.out.println("Existe conjuncao entre horarios! Plano impossivel de desenvolver.");
                return true;
            } else {
                for (int i = 0; i < textFile.size(); i++) {
                    writer.println(textFile.get(i));
                }
            }
        }
        return false;
    }

    //Verifica se uma hora final de rega coincide com o horario inicial da proxima sequencia de regas do dia
    private static boolean verificarConjuncaoHorarios(List<String> horasFinais) throws ParseException {
        for (int i = 0; i < horasDeRega.size(); i++) {
            for (int j = 0; j < horasFinais.size(); j++) {
                if (!Objects.equals(horasDeRega.get(i), encontrarHoraMaisProxima(horasFinais.get(i).split(":")[0], horasFinais.get(i).split(":")[1]))) {
                    if (converterParaSegundos(horasFinais.get(i)) > converterParaSegundos(horasDeRega.get(i))) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private static String adicionarMinutos(String hora, int minutos) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm");
        Calendar calendar = Calendar.getInstance();

        try {
            calendar.setTime(dateFormat.parse(hora));
        } catch (Exception e) {
            e.printStackTrace();
        }

        calendar.add(Calendar.MINUTE, minutos);
        return dateFormat.format(calendar.getTime());
    }

    public static int converterParaSegundos(String horaMinuto) throws ParseException {
        // Define o formato da hora
        SimpleDateFormat formato = new SimpleDateFormat("HH:mm");

        // Parseia a String para um objeto Date
        Date data = formato.parse(horaMinuto);

        // Extrai horas e minutos do objeto Date
        int horas = data.getHours();
        int minutos = data.getMinutes();

        // Calcula os segundos
        int segundos = horas * 3600 + minutos * 60;

        return segundos;
    }

}