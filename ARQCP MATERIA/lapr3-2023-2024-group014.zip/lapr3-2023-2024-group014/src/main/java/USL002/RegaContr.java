package USL002;

public class RegaContr {
    private int dia;
    private String setor;
    private int duracao;
    private String horaInicio;
    private  String horaFim;

    public RegaContr(int dia, String setor, int duracao, String horaInicio, String horaFim) {
        this.dia = dia;
        this.setor = setor;
        this.duracao = duracao;
        this.horaInicio = horaInicio;
        this.horaFim = horaFim;
    }

    public int getDia() {
        return dia;
    }

    public void setDia(int dia) {
        this.dia = dia;
    }

    public String getSetor() {
        return setor;
    }

    public void setSetor(String setor) {
        this.setor = setor;
    }

    public int getDuracao() {
        return duracao;
    }

    public void setDuracao(int duracao) {
        this.duracao = duracao;
    }

    public String getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(String horaInicio) {
        this.horaInicio = horaInicio;
    }

    public String getHoraFim() {
        return horaFim;
    }

    public void setHoraFim(String horaFim) {
        this.horaFim = horaFim;
    }
}
