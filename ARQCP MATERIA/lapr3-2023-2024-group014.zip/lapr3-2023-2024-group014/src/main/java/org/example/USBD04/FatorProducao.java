package org.example.USBD04;

import java.util.ArrayList;
import java.util.List;

public class FatorProducao {
    private String designacao;
    private String fabricante;
    private String formato;
    private String tipo;
    private String aplicacao;
    private List<String> componentes;
    private List<Double> percentagens;

    public FatorProducao(String designacao, String fabricante, String formato, String tipo, String aplicacao) {
        this.designacao = designacao;
        this.fabricante = fabricante;
        this.formato = formato;
        this.tipo = tipo;
        this.aplicacao = aplicacao;
        this.componentes = new ArrayList<>();
        this.percentagens = new ArrayList<>();
    }

    public void adicionarComponente(String componente, double percentagem) {
        this.componentes.add(componente);
        this.percentagens.add(percentagem);
    }

    public String getDesignacao() {
        return designacao;
    }

    public void setDesignacao(String designacao) {
        this.designacao = designacao;
    }

    public String getFabricante() {
        return fabricante;
    }

    public void setFabricante(String fabricante) {
        this.fabricante = fabricante;
    }

    public String getFormato() {
        return formato;
    }

    public void setFormato(String formato) {
        this.formato = formato;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getAplicacao() {
        return aplicacao;
    }

    public void setAplicacao(String aplicacao) {
        this.aplicacao = aplicacao;
    }

    public List<String> getComponentes() {
        return componentes;
    }

    public void setComponentes(List<String> componentes) {
        this.componentes = componentes;
    }

    public List<Double> getPercentagens() {
        return percentagens;
    }

    public void setPercentagens(List<Double> percentagens) {
        this.percentagens = percentagens;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Designação: ").append(designacao).append("\n");
        sb.append("Fabricante: ").append(fabricante).append("\n");
        sb.append("Formato: ").append(formato).append("\n");
        sb.append("Tipo: ").append(tipo).append("\n");
        sb.append("Aplicação: ").append(aplicacao).append("\n");
        sb.append("Componentes: ").append(componentes).append("\n");
        sb.append("Percentagens: ").append(percentagens).append("\n");
        return sb.toString();
    }

}
