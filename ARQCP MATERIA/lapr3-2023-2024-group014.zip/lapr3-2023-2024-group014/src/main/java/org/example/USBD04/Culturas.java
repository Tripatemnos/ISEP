package org.example.USBD04;

public class Culturas {
    private int id;
    private String parcela;
    private String cultura;
    private String tipo;
    private String dataInicial;
    private String dataFinal;
    private double quantidade;
    private String unidades;

    // Constructor
    public Culturas(int id, String parcela, String cultura, String tipo, String dataInicial, String dataFinal, double quantidade, String unidades) {
        this.id = id;
        this.parcela = parcela;
        this.cultura = cultura;
        this.tipo = tipo;
        this.dataInicial = dataInicial;
        this.dataFinal = dataFinal;
        this.quantidade = quantidade;
        this.unidades = unidades;
    }

    // Getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getParcela() {
        return parcela;
    }

    public void setParcela(String parcela) {
        this.parcela = parcela;
    }

    public String getCultura() {
        return cultura;
    }

    public void setCultura(String cultura) {
        this.cultura = cultura;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getDataInicial() {
        return dataInicial;
    }

    public void setDataInicial(String dataInicial) {
        this.dataInicial = dataInicial;
    }

    public String getDataFinal() {
        return dataFinal;
    }

    public void setDataFinal(String dataFinal) {
        this.dataFinal = dataFinal;
    }

    public double getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(double quantidade) {
        this.quantidade = quantidade;
    }

    public String getUnidades() {
        return unidades;
    }

    public void setUnidades(String unidades) {
        this.unidades = unidades;
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Parcela: " + parcela + ", Cultura: " + cultura +
                ", Tipo: " + tipo + ", Data Inicial: " + dataInicial + ", Data Final: " +
                dataFinal  + ", Quantidade: " + quantidade +
                ", Unidades: " + unidades;
    }


}
