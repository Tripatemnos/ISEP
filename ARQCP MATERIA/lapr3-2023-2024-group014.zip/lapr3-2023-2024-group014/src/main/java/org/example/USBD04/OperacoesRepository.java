package org.example.USBD04;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class OperacoesRepository {
    public static List<Operacao> lerOperacoesDoCSV(String caminhoDoArquivo) {
        List<Operacao> operacaos = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(caminhoDoArquivo))) {
            String line;
            boolean isFirstLine = true;

            while ((line = br.readLine()) != null) {
                // Skip the header line
                if (isFirstLine) {
                    isFirstLine = false;
                    continue;
                }

                String[] partes = line.split(";");

                int idParcela = Integer.parseInt(partes[0].trim());
                String parcela = partes.length > 1 ? partes[1].trim().isEmpty() ? null : partes[1].trim() : null;
                String operacao = partes.length > 2 ? partes[2].trim().isEmpty() ? null : partes[2].trim() : null;
                String modo = partes.length > 3 ? partes[3].trim().isEmpty() ? null : partes[3].trim() : null;
                String cultura = partes.length > 4 ? partes[4].trim().isEmpty() ? null : partes[4].trim() : null;
                String data = partes.length > 5 ? partes[5].trim().isEmpty() ? null : partes[5].trim() : null;
                double quantidade = partes.length > 6 ? partes[6].trim().isEmpty() ? 0.0 : Double.parseDouble(partes[6].trim().replace(",", ".")) : 0.0;
                String unidade = partes.length > 7 ? partes[7].trim().isEmpty() ? null : partes[7].trim() : null;
                String fatorProducao = partes.length > 8 ? partes[8].trim().isEmpty() ? null : partes[8].trim() : null;

                Operacao operacaoObj = new Operacao(idParcela, parcela, operacao, modo, cultura, data, quantidade, unidade, fatorProducao);
                operacaos.add(operacaoObj);
            }



        } catch (IOException e) {

        }

        return operacaos;
    }


}
