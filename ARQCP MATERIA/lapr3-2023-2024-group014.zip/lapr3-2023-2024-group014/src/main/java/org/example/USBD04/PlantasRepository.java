package org.example.USBD04;

import org.example.USBD04.Plantas;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class PlantasRepository {
    public static List<Plantas> lerPlantasDoCSV(String caminhoDoArquivo) {
        List<Plantas> plantas = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(caminhoDoArquivo))) {
            String line;
            boolean isFirstLine = true;

            while ((line = br.readLine()) != null) {
                // Skip the header line
                if (isFirstLine) {
                    isFirstLine = false;
                    continue;
                }

                String[] partes = line.split(";");

                if (partes.length >= 8) {
                    String especie = partes[0];
                    String nomeComum = partes[1];
                    String variedade = partes[2];
                    String tipoPlantacao = partes[3];
                    String sementeiraPlantacao = partes[4].isEmpty() ? null : partes[4];
                    String poda = partes[5].isEmpty() ? null : partes[5];
                    String floracao = partes[6].isEmpty() ? null : partes[6];
                    String colheita = partes[7].isEmpty() ? null : partes[7];

                    Plantas planta = new Plantas(especie, nomeComum, variedade, tipoPlantacao, sementeiraPlantacao, poda, floracao, colheita);
                    plantas.add(planta);
                }
            }
        } catch (IOException e) {
            System.out.println("Erro ao abrir o arquivo: " + e.getMessage());
            e.printStackTrace();
        }

        return plantas;
    }


}
