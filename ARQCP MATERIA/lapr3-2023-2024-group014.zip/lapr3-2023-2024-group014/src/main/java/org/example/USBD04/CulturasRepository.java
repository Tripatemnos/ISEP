package org.example.USBD04;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

public class CulturasRepository {
    public static List<Culturas> lerCulturasDoCSV(String caminhoDoArquivo) {
        List<Culturas> culturas = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(caminhoDoArquivo))) {
            String line;
            boolean isFirstLine = true;

            while ((line = br.readLine()) != null) {
                // Skip the header line
                if (isFirstLine) {
                    isFirstLine = false;
                    continue;
                }

                String[] partes = line.split(";");

                if (partes.length >= 8) {
                    int id = Integer.parseInt(partes[0]);
                    String parcela = partes[1];
                    String cultura = partes[2];
                    String tipo = partes[3];
                    String dataInicial = partes[4];
                    String dataFinal = partes[5].isEmpty() ? null : partes[5];
                    double quantidade = Double.parseDouble(partes[6].replace(",", "."));
                    String unidades = partes[7];

                    Culturas culturaObj = new Culturas(id, parcela, cultura, tipo, dataInicial, dataFinal, quantidade, unidades);
                    culturas.add(culturaObj);

                }
            }
        } catch (IOException e) {

        }

        return culturas;
    }
}
