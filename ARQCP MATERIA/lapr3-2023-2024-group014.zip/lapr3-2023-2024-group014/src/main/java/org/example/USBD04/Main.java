package org.example.USBD04;

import org.example.USBD04.Plantas;
import org.example.USBD04.PlantasRepository;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        List<Plantas> plantas = PlantasRepository.lerPlantasDoCSV("plantas_v2.csv");
        List<Culturas> culturas = CulturasRepository.lerCulturasDoCSV("culturas_v2.csv");
        List<ExploracaoAgricola> exploracoes = ExploracaoAgricolaRepository.lerExploracaoAgricolaDoCSV("exploracaoAgricola_v2.csv");
        List<FatorProducao> fatorProducaos = FatorProducaoRepository.lerFatoresProducaoDoCSV("fatorProducao_v2.csv");
        List<Operacao> operacaos = OperacoesRepository.lerOperacoesDoCSV("operacoes_v2.csv");
        List<String> tipoEdifico = TipoEdificio(exploracoes);
        List<String> permanencia = PermanenciaTable(culturas);
        List<String> fabricnateFatorProducao = FabricanteFatorProducao(fatorProducaos);
        List<String> formatoFatorProducao = FormatoFatorProducao(fatorProducaos);
        List<String> tipoFatorProducao = TipoFatorProducao(fatorProducaos);
        List<String> especiePlanta = EspeciePlanta(plantas);
        List<String> aplicacao = Aplicacao(fatorProducaos);
        List<String> fatorProducaoMe = FatorProducaoMe(fatorProducaos);
        List<String> componente = Componente(fatorProducaos);
        List<String> tipoOperacao = TipoOperacao(operacaos);
        List<String> edificioAgricola = EdificioAgricola(exploracoes);

        List<String> exploracaoAgricola = exploracaoAgricola(exploracoes);
        List<String> parcela = Parcela(exploracoes);
        List<String> aplicacaoFatorProducao = aplicacaoFatorProducao(fatorProducaos);
        List<String> componenteFatorProducao = componenteFatorProducao(fatorProducaos);
        List<String> cultura = cultura(culturas);
        List<String> plant = plant(plantas);
        List<String> operacao = operacao(operacaos);
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("insert_v3.sql"))) {
            writeListToFile(writer, tipoEdifico);
            writeListToFile(writer, permanencia);
            writeListToFile(writer, fabricnateFatorProducao);
            writeListToFile(writer, formatoFatorProducao);
            writeListToFile(writer, tipoFatorProducao);
            writeListToFile(writer, especiePlanta);
            writeListToFile(writer, aplicacao);
            writeListToFile(writer, fatorProducaoMe);
            writeListToFile(writer, componente);
            writeListToFile(writer, tipoOperacao);
            writeListToFile(writer, edificioAgricola);
            writeListToFile(writer, exploracaoAgricola);
            writeListToFile(writer, aplicacaoFatorProducao);
            writeListToFile(writer, parcela);
            writeListToFile(writer, componenteFatorProducao);
            writeListToFile(writer, cultura);
            writeListToFile(writer, plant);
            writeListToFile(writer, operacao);

            System.out.println("Data written to insert.sql successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static List<String> Parcela(List<ExploracaoAgricola> exploracoes) {
        System.out.println("-- Insert into Parcela table");
        List<String> finalfinal = new ArrayList<>();
        List<String> id = new ArrayList<>();


        for (int i = 0; i < exploracoes.size(); i++) {
            String id1 = String.valueOf(exploracoes.get(i).getId());
            String qnt = String.valueOf(exploracoes.get(i).getArea());
            String designacaoUni = exploracoes.get(i).getUnidade();
            String tipo = exploracoes.get(i).getTipo();

            String final1;
            if (Objects.equals(tipo, "Parcela")) {
                if (designacaoUni != null) {
                    final1 = "INSERT INTO Parcela (ExploracaoAgricolaId, UnidadeQuantidade, UnidadeDesignacao) VALUES (" + id1 + ", " + qnt + ", '" + designacaoUni + "');";
                } else {
                    final1 = "INSERT INTO Parcela (ExploracaoAgricolaId, UnidadeQuantidade, UnidadeDesignacao) VALUES (" + id1 + ", " + "0" + ", " + "NULL" + ");";

                }
                boolean found = false;
                for (int j = 0; j < id.size(); j++) {
                    if (Objects.equals(id.get(j), id1)) {
                        found = true;
                    }

                }
                if (!found) {
                    finalfinal.add(final1);
                    id.add(id1);

                }

            }
        }
        return finalfinal;
    }

    private static List<String> TipoEdificio(List<ExploracaoAgricola> exploracoes) {
        System.out.println("-- Insert into TipoEdificio table");
        List<String> tipos = new ArrayList<>();
        List<String> tipo = new ArrayList<>();
        for (int i = 0; i < exploracoes.size(); i++) {
            String perm = exploracoes.get(i).getTipo();
            String final1 = "INSERT INTO TipoEdificioAgricola (TipoEdificio) VALUES ('" + perm + "');";
            boolean found = false;

            for (int j = 0; j < tipo.size(); j++) {
                if (Objects.equals(tipo.get(j), perm)) {
                    found = true;
                }

            }
            if (!found) {
                tipos.add(final1);
                tipo.add(perm);
            }
        }
        return tipos;

    }


    private static void writeListToFile(BufferedWriter writer, List<String> list) throws IOException {
        for (String item : list) {
            writer.write(item);
            writer.newLine();
        }
    }


    private static List<String> operacao(List<Operacao> operacaos) {
        System.out.println("-- Insert into Operacao table");
        List<String> finalfinal = new ArrayList<>();
        int contador = 1;

        for (int i = 0; i < operacaos.size(); i++) {
            String parcela1 = String.valueOf(operacaos.get(i).getIdParcela());
            String tipoOperacao = operacaos.get(i).getOperacao();
            String cultura = operacaos.get(i).getCultura();
            String data = operacaos.get(i).getData();


            Double qnt = operacaos.get(i).getQuantidade() != 0 ? operacaos.get(i).getQuantidade() : 0.0;
            String uni = operacaos.get(i).getUnidade();
            String fatorProducao = operacaos.get(i).getFatorProducao();


            uni = (uni != null) ? "'" + uni + "'" : "NULL";
            fatorProducao = (fatorProducao != null) ? "'" + fatorProducao + "'" : "NULL";

            String final1 = "INSERT INTO Operacao (OperacaoId, ParcelaId, TipoOperacaoDesignacao, CulturaCulturaDesignacao, CulturaDataInicio, Quantidade, UnidadeDesignacao, FatorProducaoDesignacao) VALUES (" + contador + ", " + parcela1 + ", '" + tipoOperacao + "', '" + cultura + "', '" + data + "', " + qnt + ", " + uni + ", " + fatorProducao + ");";
            boolean found = false;

            for (int j = 0; j < finalfinal.size(); j++) {
                if (Objects.equals(finalfinal.get(j), final1)) {
                    found = true;
                }
            }

            if (!found) {
                finalfinal.add(final1);

                contador++;

            }
        }

        return finalfinal;
    }


    private static List<String> plant(List<Plantas> plantas) {
        System.out.println("-- Insert into Planta table");
        List<String> finalfinal = new ArrayList<>();
        List<String> variedade1 = new ArrayList<>();

        for (int i = 0; i < plantas.size(); i++) {
            String especie = plantas.get(i).getEspecie();
            String variedade = plantas.get(i).getVariedade();
            String permanencia = plantas.get(i).getTipoPlantacao();
            String sementeira = plantas.get(i).getSementeiraPlantacao();
            String poda = plantas.get(i).getPoda();
            String floracao = plantas.get(i).getFloracao();
            String colheita = plantas.get(i).getColheita();
            if (variedade != null) {
                variedade = variedade.replace("'", "");
            }

            if (especie != null) {
                // Handle null values for duration fields
                String sementeiraValue = (sementeira != null) ? "'" + sementeira + "'" : "NULL";
                String podaValue = (poda != null) ? "'" + poda + "'" : "NULL";
                String floracaoValue = (floracao != null) ? "'" + floracao + "'" : "NULL";
                String colheitaValue = (colheita != null) ? "'" + colheita + "'" : "NULL";

                String final1 = "INSERT INTO Planta (EspeciePlantaEspecieNome, Variedade, PermanenciaTipo, SementeiraDuracao, PodaDuracao, FloracaoDuracao, ColheitaDuracao) VALUES ('" + especie + "', '" + variedade + "', '" + permanencia + "', " + sementeiraValue + ", " + podaValue + ", " + floracaoValue + ", " + colheitaValue + ");";

                boolean found = false;
                for (int j = 0; j < variedade1.size(); j++) {
                    if (Objects.equals(variedade1.get(j), variedade)) {
                        found = true;
                    }
                }
                if (!found) {
                    finalfinal.add(final1);
                    variedade1.add(variedade);
                }
            }
        }

        return finalfinal;
    }


    private static List<String> cultura(List<Culturas> culturas) {
        System.out.println("-- Insert into Cultura table");
        List<String> finalfinal = new ArrayList<>();
        List<String> id1 = new ArrayList<>();
        List<String> cultura = new ArrayList<>();
        List<String> dataIncio = new ArrayList<>();


        for (int i = 0; i < culturas.size(); i++) {
            String id = String.valueOf(culturas.get(i).getId());
            String tipo = culturas.get(i).getTipo();
            String designcao = culturas.get(i).getCultura();

            String dataInicial = culturas.get(i).getDataInicial();
            String dataFinal = culturas.get(i).getDataFinal();
            String quantidade = String.valueOf(culturas.get(i).getQuantidade());
            String unidades = culturas.get(i).getUnidades();

            String final1;
            if (tipo != null) {
                if (tipo.equals("Permanente")) {

                    final1 = "INSERT INTO Cultura (ParcelaExploracaoAgricolaId, PermanenciaTipo, CulturaDesignacao, DataInicioCultura, DataFinalCultura, Quantidade, UnidadeDesignacao) VALUES (" + id + ", '" + tipo + "', '" + designcao + "', '" + dataInicial + "', " + "NULL" + ", " + quantidade + ", '" + unidades + "');";
                } else {
                    final1 = "INSERT INTO Cultura (ParcelaExploracaoAgricolaId, PermanenciaTipo, CulturaDesignacao, DataInicioCultura, DataFinalCultura, Quantidade, UnidadeDesignacao) VALUES (" + id + ", '" + tipo + "', '" + designcao + "', '" + dataInicial + "', '" + dataFinal + "', " + quantidade + ", '" + unidades + "');";

                }
                boolean found = false;
                for (int j = 0; j < id1.size(); j++) {
                    if (Objects.equals(id1.get(j), id) && Objects.equals(cultura.get(j), designcao) && Objects.equals(dataIncio.get(j), dataInicial)) {
                        found = true;
                    }

                }
                if (!found) {
                    finalfinal.add(final1);
                    id1.add(id);
                    cultura.add(designcao);
                    dataIncio.add(dataInicial);

                }
            }
        }
        return finalfinal;
    }

    private static List<String> componenteFatorProducao(List<FatorProducao> fatorProducaos) {

        System.out.println("-- Insert into ComponenteFatorProducao table");
        List<String> finalfinal = new ArrayList<>();
        Set<String> uniqueEntries = new HashSet<>();

        for (FatorProducao fatorProducao : fatorProducaos) {
            String designacao = fatorProducao.getDesignacao();
            List<String> componentes = fatorProducao.getComponentes();
            List<Double> percentagens = fatorProducao.getPercentagens();

            if (componentes != null && percentagens != null && componentes.size() == percentagens.size()) {
                for (int i = 0; i < componentes.size(); i++) {
                    String componente = componentes.get(i);
                    double percentagem = percentagens.get(i);


                    String final1 = "INSERT INTO ComponenteFatorProducao (ComponenteDesignacao, ComponentePercentagem, FatorProducaoDesignacao) VALUES ('" + componente + "', " + percentagem + ", '" + designacao + "');";


                    String uniqueEntry = designacao + componente + percentagem;
                    if (uniqueEntries.add(uniqueEntry)) {
                        finalfinal.add(final1);
                    }
                }
            }
        }

        return finalfinal;
    }


    private static List<String> aplicacaoFatorProducao(List<FatorProducao> fatorProducaos) {
        System.out.println("-- Insert into AplicacaoFatorProducao table");
        Map<String, List<String>> aplicacoesMap = new LinkedHashMap<>();
        List<String> finalfinal = new ArrayList<>();
        for (int i = 0; i < fatorProducaos.size(); i++) {
            String designacao = fatorProducaos.get(i).getDesignacao();
            String aplicacoesString = fatorProducaos.get(i).getAplicacao();

            if (aplicacoesString != null && !aplicacoesString.isEmpty()) {
                String[] aplicacoes = aplicacoesString.split("\\+");
                aplicacoesMap.putIfAbsent(designacao, new ArrayList<>());
                aplicacoesMap.get(designacao).addAll(Arrays.asList(aplicacoes));
            }
        }

        for (Map.Entry<String, List<String>> entry : aplicacoesMap.entrySet()) {
            String designacao = entry.getKey();
            List<String> aplicacoes = entry.getValue();

            for (String aplicacao : aplicacoes) {
                String final1 = "INSERT INTO AplicacaoFatorProducao (AplicacaoProducao, FatorProducaoDesignacao) VALUES ('" + aplicacao.trim() + "', '" + designacao + "');";
                finalfinal.add(final1);
            }
        }
        return finalfinal;
    }


    private static List<String> exploracaoAgricola(List<ExploracaoAgricola> exploracoes) {
        System.out.println("-- Insert into ExploracaoAgricola table");
        List<String> finalfinal = new ArrayList<>();
        List<String> id = new ArrayList<>();


        for (int i = 0; i < exploracoes.size(); i++) {
            String id1 = String.valueOf(exploracoes.get(i).getId());
            String qnt = String.valueOf(exploracoes.get(i).getArea());
            String designacaoUni = exploracoes.get(i).getUnidade();

            String final1;
            if (designacaoUni != null) {
                final1 = "INSERT INTO ExploracaoAgricola (ExploracaoId, UnidadeQuantidade, UnidadeDesignacao) VALUES (" + id1 + ", " + qnt + ", '" + designacaoUni + "');";
            } else {
                final1 = "INSERT INTO ExploracaoAgricola (ExploracaoId, UnidadeQuantidade, UnidadeDesignacao) VALUES (" + id1 + ", " + "0" + ", " + "NULL" + ");";

            }
            boolean found = false;
            for (int j = 0; j < id.size(); j++) {
                if (Objects.equals(id.get(j), id1)) {
                    found = true;
                }

            }
            if (!found) {
                finalfinal.add(final1);
                id.add(id1);

            }
        }
        return finalfinal;
    }

    private static List<String> EdificioAgricola(List<ExploracaoAgricola> exploracoes) {
        System.out.println("-- Insert into EdificioAgricola table");
        List<String> finalfinal = new ArrayList<>();
        List<String> id1 = new ArrayList<>();


        for (int i = 0; i < exploracoes.size(); i++) {
            String id = String.valueOf(exploracoes.get(i).getId());
            String tipo = exploracoes.get(i).getTipo();
            String designacao = exploracoes.get(i).getDesignacao();
            if (tipo != null) {
                String final1 = "INSERT INTO EdificioAgricola (ExploracaoId, TipoEdificioAgricola, DesignacaoEdificio) VALUES (" + id + ", '" + tipo + "', '" + designacao + "');";
                boolean found = false;
                for (int j = 0; j < id1.size(); j++) {
                    if (Objects.equals(id1.get(j), id)) {
                        found = true;
                    }

                }
                if (!found) {
                    finalfinal.add(final1);
                    id1.add(id);

                }
            }
        }
        return finalfinal;
    }

    private static List<String> TipoOperacao(List<Operacao> operacaos) {
        System.out.println("-- Insert into TipoOperacao table");
        List<String> finalfinal = new ArrayList<>();
        List<String> tipo1 = new ArrayList<>();

        for (int i = 0; i < operacaos.size(); i++) {
            String tipo = operacaos.get(i).getOperacao();
            String modo = operacaos.get(i).getModo();
            if (tipo != null) {
                String modo1 = (modo != null) ? "'" + modo + "'" : "NULL";
                String final1 = "INSERT INTO TipoOperacao (TipoOperacao, Modo) VALUES ('" + tipo + "', " + modo1 + ");";
                boolean found = false;
                for (int j = 0; j < tipo1.size(); j++) {
                    if (Objects.equals(tipo1.get(j), tipo)) {
                        found = true;
                    }

                }
                if (!found) {
                    finalfinal.add(final1);
                    tipo1.add(tipo);
                }
            }
        }
        return finalfinal;
    }

    private static List<String> Componente(List<FatorProducao> fatorProducaos) {
        System.out.println("-- Insert into Componente table");
        List<String> finalfinal = new ArrayList<>();
        List<String> comp1 = new ArrayList<>();
        List<String> perc1 = new ArrayList<>();


        for (int i = 0; i < fatorProducaos.size(); i++) {
            List<String> comp = fatorProducaos.get(i).getComponentes();
            List<Double> perc = fatorProducaos.get(i).getPercentagens();
            int cont = 0;
            while (cont != comp.size()) {
                String componente = comp.get(cont);
                String percentagem = String.valueOf(perc.get(cont));
                String final1 = "INSERT INTO Componente (DesignacaoComponente, PercentagemComponente) VALUES ('" + componente + "', " + percentagem + ");";
                boolean found = false;
                for (int j = 0; j < comp1.size(); j++) {
                    if (Objects.equals(comp1.get(j), componente) && Objects.equals(perc1.get(j), percentagem)) {
                        found = true;
                    }

                }
                if (!found) {
                    finalfinal.add(final1);
                    comp1.add(componente);
                    perc1.add(percentagem);
                }
                cont++;
            }
        }
        return finalfinal;
    }

    private static List<String> FatorProducaoMe(List<FatorProducao> fatorProducaos) {
        System.out.println("-- Insert into FatorProducao table");
        List<String> finalfinal = new ArrayList<>();
        List<String> des = new ArrayList<>();


        for (int i = 0; i < fatorProducaos.size(); i++) {
            String designacao = fatorProducaos.get(i).getDesignacao();
            String fabricante = fatorProducaos.get(i).getFabricante();
            String formato = fatorProducaos.get(i).getFormato();
            String tipo = fatorProducaos.get(i).getTipo();
            if (tipo != null) {
                String final1 = "INSERT INTO FatorProducao (Designacao, FabricanteFatorProducao, FormatoFatorProducao, TipoFatorProducao) VALUES ('" + designacao + "', '" + fabricante + "', '" + formato + "', '" + tipo + "');";
                boolean found = false;
                for (int j = 0; j < des.size(); j++) {
                    if (Objects.equals(des.get(j), designacao)) {
                        found = true;
                    }

                }
                if (!found) {
                    finalfinal.add(final1);
                    des.add(designacao);
                }
            }
        }
        return finalfinal;
    }

    private static List<String> Aplicacao(List<FatorProducao> fatorProducaos) {
        System.out.println("-- Insert into Aplicacao table");
        List<String> finalfinal = new ArrayList<>();
        List<String> apl = new ArrayList<>();

        for (int i = 0; i < fatorProducaos.size(); i++) {
            String tipo = fatorProducaos.get(i).getAplicacao();
            if (tipo != null && tipo.contains("+")) {
                String[] parts = tipo.split("\\+");
                for (String part : parts) {
                    String final1 = "INSERT INTO Aplicacao (AplicacaoProducao) VALUES ('" + part.trim() + "');";
                    boolean found = false;
                    for (int j = 0; j < apl.size(); j++) {
                        if (Objects.equals(apl.get(j), part.trim())) {
                            found = true;
                        }
                    }
                    if (!found) {
                        finalfinal.add(final1);
                        apl.add(part.trim());
                    }
                }
            } else if (tipo != null) {
                String final1 = "INSERT INTO Aplicacao (AplicacaoProducao) VALUES ('" + tipo.trim() + "');";
                boolean found = false;
                for (int j = 0; j < apl.size(); j++) {
                    if (Objects.equals(apl.get(j), tipo.trim())) {
                        found = true;
                    }
                }
                if (!found) {
                    finalfinal.add(final1);
                    apl.add(tipo.trim());
                }
            }
        }

        return finalfinal;
    }


    private static List<String> EspeciePlanta(List<Plantas> plantas) {
        System.out.println("-- Insert into EspeciePlanta table");
        List<String> finalfinal = new ArrayList<>();

        List<String> especieNome = new ArrayList<>();

        for (int i = 0; i < plantas.size(); i++) {
            String especie = plantas.get(i).getEspecie();
            String nomeComum = plantas.get(i).getNomeComum();
            if (especie != null) {
                String final1 = "INSERT INTO EspeciePlanta (EspecieNome, NomeComum) VALUES ('" + especie + "', '" + nomeComum + "');";
                boolean found = false;
                for (int j = 0; j < especieNome.size(); j++) {
                    if (Objects.equals(especieNome.get(j), especie)) {
                        found = true;
                    }

                }
                if (!found) {
                    finalfinal.add(final1);
                    especieNome.add(especie);

                }
            }
        }
        return finalfinal;
    }

    private static List<String> TipoFatorProducao(List<FatorProducao> fatorProducaos) {
        System.out.println("-- Insert into TipoFatorProducao table");
        List<String> finalfinal = new ArrayList<>();
        List<String> tipoFator = new ArrayList<>();

        for (int i = 0; i < fatorProducaos.size(); i++) {
            String tipo = fatorProducaos.get(i).getTipo();
            if (tipo != null) {
                String final1 = "INSERT INTO TipoFatorProducao (TipoProducao) VALUES ('" + tipo + "');";
                boolean found = false;
                for (int j = 0; j < tipoFator.size(); j++) {
                    if (Objects.equals(tipoFator.get(j), tipo)) {
                        found = true;
                    }

                }
                if (!found) {
                    finalfinal.add(final1);
                    tipoFator.add(tipo);
                }
            }
        }
        return finalfinal;
    }

    private static List<String> FormatoFatorProducao(List<FatorProducao> fatorProducaos) {
        System.out.println("-- Insert into FormatoFatorProducao table");
        List<String> finalfinal = new ArrayList<>();
        List<String> formato1 = new ArrayList<>();

        for (int i = 0; i < fatorProducaos.size(); i++) {
            String formato = fatorProducaos.get(i).getFormato();
            if (formato != null) {
                String final1 = "INSERT INTO FormatoFatorProducao (FormatoDesigncao) VALUES ('" + formato + "');";
                boolean found = false;
                for (int j = 0; j < formato1.size(); j++) {
                    if (Objects.equals(formato1.get(j), formato)) {
                        found = true;
                    }

                }
                if (!found) {
                    finalfinal.add(final1);
                    formato1.add(formato);
                }
            }
        }
        return finalfinal;
    }

    private static List<String> FabricanteFatorProducao(List<FatorProducao> fatorProducaos) {
        System.out.println("-- Insert into FabricanteFatorProducao table");
        List<String> finalfinal = new ArrayList<>();
        List<String> fabricante1 = new ArrayList<>();


        for (int i = 0; i < fatorProducaos.size(); i++) {
            String fabricante = fatorProducaos.get(i).getFabricante();
            if (fabricante != null) {
                String final1 = "INSERT INTO FabricanteFatorProducao (FabricanteDesignacao) VALUES ('" + fabricante + "');";
                boolean found = false;
                for (int j = 0; j < fabricante1.size(); j++) {
                    if (Objects.equals(fabricante1.get(j), fabricante)) {
                        found = true;
                    }

                }
                if (!found) {
                    finalfinal.add(final1);
                    fabricante1.add(fabricante);
                }
            }
        }
        return finalfinal;
    }


    private static List<String> PermanenciaTable(List<Culturas> culturas) {
        System.out.println("-- Insert into Permanencia table");
        List<String> permanencias = new ArrayList<>();
        List<String> tipo = new ArrayList<>();
        for (int i = 0; i < culturas.size(); i++) {
            String perm = culturas.get(i).getTipo();
            String final1 = "INSERT INTO Permanencia (PermanenciaTipo) VALUES ('" + perm + "');";
            boolean found = false;

            for (int j = 0; j < tipo.size(); j++) {
                if (Objects.equals(tipo.get(j), perm)) {
                    found = true;
                }

            }
            if (!found) {
                permanencias.add(final1);
                tipo.add(perm);
            }
        }
        return permanencias;

    }
}