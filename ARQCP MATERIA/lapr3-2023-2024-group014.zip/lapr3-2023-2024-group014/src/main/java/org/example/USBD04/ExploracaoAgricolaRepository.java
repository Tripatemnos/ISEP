package org.example.USBD04;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ExploracaoAgricolaRepository {
    public static List<ExploracaoAgricola> lerExploracaoAgricolaDoCSV(String caminhoDoArquivo) {
        List<ExploracaoAgricola> exploracoes = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(caminhoDoArquivo))) {
            String line;
            boolean primeiraLinha = true;

            while ((line = br.readLine()) != null) {
                // Ignorar a primeira linha (rótulos de coluna)
                if (primeiraLinha) {
                    primeiraLinha = false;
                    continue;
                }

                // Restante do código para processar os dados como antes
                String[] partes = line.split(";", -1);

                int id = Integer.parseInt(partes[0]);
                String tipo = partes[1];
                String designacao = partes[2];
                Double area = null;
                boolean temarea = false;
                if (partes[3] != null && !partes[3].isEmpty() && !partes[3].equalsIgnoreCase("null")) {
                    area = Double.parseDouble(partes[3].replace(",", "."));
                    temarea = true;
                }
                String unidade = partes[4].isEmpty() || partes[4].equals("null") ? null : partes[4];
                if (temarea) {
                    ExploracaoAgricola exploracao = new ExploracaoAgricola(id, tipo, designacao, area, unidade);
                    exploracoes.add(exploracao);
                } else {
                    ExploracaoAgricola exploracao = new ExploracaoAgricola(id, tipo, designacao, unidade);
                    exploracoes.add(exploracao);
                }
            }
        } catch (IOException e) {
            System.out.println("Erro ao ler o arquivo: " + e.getMessage());
        }

        return exploracoes;
    }
}
