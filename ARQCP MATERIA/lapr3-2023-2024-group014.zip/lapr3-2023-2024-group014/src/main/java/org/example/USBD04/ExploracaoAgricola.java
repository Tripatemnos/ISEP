package org.example.USBD04;

public class ExploracaoAgricola {
    private int id;
    private String tipo;
    private String designacao;
    private double area;
    private String unidade;

    public ExploracaoAgricola(int id, String tipo, String designacao, double area, String unidade) {
        this.id = id;
        this.tipo = tipo;
        this.designacao = designacao;
        this.area = area;
        this.unidade = unidade;
    }
    public ExploracaoAgricola(int id, String tipo, String designacao,  String unidade) {
        this.id = id;
        this.tipo = tipo;
        this.designacao = designacao;
        this.unidade = unidade;
    }
    // Getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getDesignacao() {
        return designacao;
    }

    public void setDesignacao(String designacao) {
        this.designacao = designacao;
    }

    public double getArea() {
        return area;
    }

    public void setArea(double area) {
        this.area = area;
    }

    public String getUnidade() {
        return unidade;
    }

    public void setUnidade(String unidade) {
        this.unidade = unidade;
    }

    @Override
    public String toString() {
        return "ExploracaoAgricola{" +
                "id=" + id +
                ", tipo='" + tipo + '\'' +
                ", designacao='" + designacao + '\'' +
                ", area=" + area +
                ", unidade='" + unidade + '\'' +
                '}';
    }
}
