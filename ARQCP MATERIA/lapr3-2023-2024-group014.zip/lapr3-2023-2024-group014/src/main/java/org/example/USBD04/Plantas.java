package org.example.USBD04;

public class Plantas {
    private String especie;
    private String nomeComum;
    private String variedade;
    private String tipoPlantacao;
    private String sementeiraPlantacao;
    private String poda;
    private String floracao;
    private String colheita;

    public Plantas(String especie, String nomeComum, String variedade, String tipoPlantacao, String sementeiraPlantacao, String poda, String floracao, String colheita) {
        this.especie = especie;
        this.nomeComum = nomeComum;
        this.variedade = variedade;
        this.tipoPlantacao = tipoPlantacao;
        this.sementeiraPlantacao = sementeiraPlantacao;
        this.poda = poda;
        this.floracao = floracao;
        this.colheita = colheita;
    }
    // Construtor sem variáveis facultativas
    public Plantas(String especie, String nomeComum, String variedade, String tipoPlantacao) {
        this(especie, nomeComum, variedade, tipoPlantacao, null, null, null, null);
    }

    // Construtor com variáveis de sementeira/plantação
    public Plantas(String especie, String nomeComum, String variedade, String tipoPlantacao, String sementeiraPlantacao) {
        this(especie, nomeComum, variedade, tipoPlantacao, sementeiraPlantacao, null, null, null);
    }

    // Construtor com variáveis de sementeira/plantação e poda
    public Plantas(String especie, String nomeComum, String variedade, String tipoPlantacao, String sementeiraPlantacao, String poda) {
        this(especie, nomeComum, variedade, tipoPlantacao, sementeiraPlantacao, poda, null, null);
    }

    // Construtor com todas as variáveis facultativas
    public Plantas(String especie, String nomeComum, String variedade, String tipoPlantacao, String sementeiraPlantacao, String poda, String floracao) {
        this(especie, nomeComum, variedade, tipoPlantacao, sementeiraPlantacao, poda, floracao, null);
    }


    // Getters e Setters
    public String getEspecie() {
        return especie;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }

    public String getNomeComum() {
        return nomeComum;
    }

    public void setNomeComum(String nomeComum) {
        this.nomeComum = nomeComum;
    }

    public String getVariedade() {
        return variedade;
    }

    public void setVariedade(String variedade) {
        this.variedade = variedade;
    }

    public String getTipoPlantacao() {
        return tipoPlantacao;
    }

    public void setTipoPlantacao(String tipoPlantacao) {
        this.tipoPlantacao = tipoPlantacao;
    }

    public String getSementeiraPlantacao() {
        return sementeiraPlantacao;
    }

    public void setSementeiraPlantacao(String sementeiraPlantacao) {
        this.sementeiraPlantacao = sementeiraPlantacao;
    }

    public String getPoda() {
        return poda;
    }

    public void setPoda(String poda) {
        this.poda = poda;
    }

    public String getFloracao() {
        return floracao;
    }

    public void setFloracao(String floracao) {
        this.floracao = floracao;
    }

    public String getColheita() {
        return colheita;
    }

    public void setColheita(String colheita) {
        this.colheita = colheita;
    }
    @Override
    public String toString() {
        return "Plantas{" +
                "especie='" + especie + '\'' +
                ", nomeComum='" + nomeComum + '\'' +
                ", variedade='" + variedade + '\'' +
                ", tipoPlantacao='" + tipoPlantacao + '\'' +
                ", sementeiraPlantacao='" + sementeiraPlantacao + '\'' +
                ", poda='" + poda + '\'' +
                ", floracao='" + floracao + '\'' +
                ", colheita='" + colheita + '\'' +
                '}';
    }

}
