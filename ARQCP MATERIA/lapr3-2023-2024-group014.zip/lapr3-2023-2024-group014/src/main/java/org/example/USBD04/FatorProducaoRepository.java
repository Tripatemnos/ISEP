package org.example.USBD04;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FatorProducaoRepository {
    public static List<FatorProducao> lerFatoresProducaoDoCSV(String caminhoDoArquivo) {
        List<FatorProducao> fatoresProducao = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(caminhoDoArquivo))) {
            String line;
            boolean isFirstLine = true;

            while ((line = br.readLine()) != null) {
                // Skip the header line
                if (isFirstLine) {
                    isFirstLine = false;
                    continue;
                }

                String[] partes = line.split(";");
                String designacao = partes[0];
                String fabricante = partes[1];
                String formato = partes[2];
                String tipo = partes[3];
                String aplicacao = partes[4];
                List<String> componentes = new ArrayList<>();
                List<Double> percentagens = new ArrayList<>();

                for (int i = 5; i < partes.length; i++) {
                    if (partes[i] != null && !partes[i].isEmpty() && i%2==0) {
                        percentagens.add(Double.parseDouble(partes[i].replace(",", ".").replace("%", "")));
                    }else if(i%2!=0){
                        componentes.add(partes[i]);
                    }
                }

                FatorProducao fatorProducao = new FatorProducao(designacao, fabricante, formato, tipo, aplicacao);
                fatorProducao.setComponentes(componentes);
                fatorProducao.setPercentagens(percentagens);

                fatoresProducao.add(fatorProducao);
            }
        } catch (IOException e) {

        }

        return fatoresProducao;
    }
}
