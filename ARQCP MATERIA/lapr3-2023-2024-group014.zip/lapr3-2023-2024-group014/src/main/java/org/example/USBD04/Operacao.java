package org.example.USBD04;

public class Operacao {

    private int idParcela;
    private String parcela;
    private String operacao;
    private String modo;
    private String cultura;
    private String data;
    private double quantidade;
    private String unidade;
    private String fatorProducao;

    public Operacao(int idParcela, String parcela, String operacao, String modo, String cultura, String data, double quantidade, String unidade, String fatorProducao) {
        this.idParcela = idParcela;
        this.parcela = parcela;
        this.operacao = operacao;
        this.modo = modo;
        this.cultura = cultura;
        this.data = data;
        this.quantidade = quantidade;
        this.unidade = unidade;
        this.fatorProducao = fatorProducao;
    }

    public Operacao(int idParcela, String parcela, String operacao, String modo, String cultura, String data, String unidade, String fatorProducao) {
        this.idParcela = idParcela;
        this.parcela = parcela;
        this.operacao = operacao;
        this.modo = modo;
        this.cultura = cultura;
        this.data = data;

        this.unidade = unidade;
        this.fatorProducao = fatorProducao;
    }

    public int getIdParcela() {
        return idParcela;
    }

    public void setIdParcela(int idParcela) {
        this.idParcela = idParcela;
    }

    public String getParcela() {
        return parcela;
    }

    public void setParcela(String parcela) {
        this.parcela = parcela;
    }

    public String getOperacao() {
        return operacao;
    }

    public void setOperacao(String operacao) {
        this.operacao = operacao;
    }

    public String getModo() {
        return modo;
    }

    public void setModo(String modo) {
        this.modo = modo;
    }

    public String getCultura() {
        return cultura;
    }

    public void setCultura(String cultura) {
        this.cultura = cultura;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public double getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(double quantidade) {
        this.quantidade = quantidade;
    }

    public String getUnidade() {
        return unidade;
    }

    public void setUnidade(String unidade) {
        this.unidade = unidade;
    }

    public String getFatorProducao() {
        return fatorProducao;
    }

    public void setFatorProducao(String fatorProducao) {
        this.fatorProducao = fatorProducao;
    }

    @Override
    public String toString() {
        return "Operacao{" +
                "idParcela=" + idParcela +
                ", parcela='" + parcela + '\'' +
                ", operacao='" + operacao + '\'' +
                ", modo='" + modo + '\'' +
                ", cultura='" + cultura + '\'' +
                ", data='" + data + '\'' +
                ", quantidade=" + quantidade +
                ", unidade='" + unidade + '\'' +
                ", fatorProducao='" + fatorProducao + '\'' +
                '}';
    }
}
