#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "processador_de_dados.h"

void insert_struct(sensor *vetor, char *dados) {
	int sensor_id = 0, id_line = 0, value = 0, time = 0, i = 0;
	    // ID comparison logic
    char token1[] = "sensor_id";
    extract_token(dados, token1, &sensor_id);


	while (vetor[i].id != NULL) {
		if (sensor_id == vetor[i].id) {
			id_line = i;
			break;
		}
        i++;
    }
    
    	 // Value comparison logic
    char token2[] = "value";
    extract_token(dados, token2, &value);
    
        // Time comparison logic
    char token3[] = "time";
    extract_token(dados, token3, &time);
    
    enqueue_value(vetor[id_line].buff->buf, vetor[id_line].buff->lenght, &(vetor[id_line].buff->read), &(vetor[id_line].buff->write), value);
    
    // FALTA ADICIONAR ELEMENTO AO ARRAY DA MEDIANA (acho que não é aqui)
    
    vetor[id_line].lastRead = time;
    vetor[id_line].write_counter++;
    
}
