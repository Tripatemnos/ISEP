#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "processador_de_dados.h"

sensor* create_struct(char *b) {
    int tamanho = 0;

    // Declare and allocate memory for the array of sensor structures
    sensor *vetor = NULL;

    // Abre o arquivo para leitura
    FILE *arquivo = fopen(b, "r");

    // Verifica se o arquivo foi aberto com sucesso
    if (arquivo == NULL) {
        perror("Erro ao abrir o arquivo");
        return NULL;  // Return NULL to indicate failure
    }

    // Leitura dos dados do arquivo
    char linha[100];  // Supondo que cada linha tem no máximo 100 caracteres
    
    while (fgets(linha, sizeof(linha), arquivo) != NULL) {
        // Token pointer
        char *token;

        // Allocate memory for a new sensor structure
        sensor *s_ptr = (sensor *)malloc(sizeof(sensor));

        // Get the first token (id)
        token = strtok(linha, "#");
        s_ptr->id = atoi(token);

        // Get the next token (type)
        token = strtok(NULL, "#");
        s_ptr->type = strdup(token);  // Allocate and copy the string

        // Get the next token (unit)
        token = strtok(NULL, "#");
        s_ptr->unit = strdup(token);  // Allocate and copy the string

        // Get the next token (buffer_len)
        token = strtok(NULL, "#");
        int buf_len = atoi(token);
        buffer *buff = (buffer *) malloc(sizeof(buffer)); // Alocate space for the new buffer
        
        buff->buf = (int *)malloc(buf_len * sizeof(int)); // Alocate space for the array that will play as a buffer
        buff->lenght = buf_len;
        buff->read = 0;
        buff->write = 0;
        
        s_ptr->buff = buff;

        // Get the next token (window_len)
        token = strtok(NULL, "#");
        int window_len = atoi(token);
        s_ptr->array = (int *)malloc(window_len * sizeof(int));

        // Get the next token (timeout)
        token = strtok(NULL, "#");
        s_ptr->timeout = atoi(token);

        // Set rest to 0
        s_ptr->lastRead = 0;
        s_ptr->write_counter = 0;

        // Add the new sensor structure to the array
        tamanho++;
        vetor = (sensor *)realloc(vetor, tamanho * sizeof(sensor));
        vetor[tamanho - 1] = *s_ptr;


    }

    // Fecha o arquivo
    fclose(arquivo);

    return vetor;
}
