#include <stdio.h>
#include <stdlib.h>
#include "processador_de_dados.h"

int main(char *a, char *b, char *c, int d) {
	a = "/dev/ttyACM0";
	b = "config.txt";
	d = 100;
	
	int i = 0, count = 0;
	
    sensor *vetor = create_struct(b);
    
    char *dados;
    fpos_t file_position;

    // Use the vetor array as needed
	while (count < d) {
		dados = obter_dados(a, &file_position);
		
		insert_struct(vetor, dados);
		
		count++;
	}

    // Don't forget to free the memory when done
    free(dados);
    while (vetor[i].id != NULL) {
		printf("id : %d\n", vetor[i].id);
		printf("type : %s\n", vetor[i].type);
		printf("unit : %s\n", vetor[i].unit);
		printf("timeout : %d\n", vetor[i].timeout);
		
		int* buf = vetor[i].buff->buf;
		int lenght = vetor[i].buff->lenght, write_count = vetor[i].write_counter, size = lenght;
		
		if (write_count <= lenght) {
			size = write_count;
		}
		
		for (int i = 0; i < size; i++) {
			printf("%d // ", *buf);
			buf++;
		}
		printf("\nlast read : %d\n", vetor[i].lastRead);
		printf("write counter : %d\n", vetor[i].write_counter);
		
	
        free(vetor[i].type);
        free(vetor[i].unit);
        free(vetor[i].buff->buf);
        free(vetor[i].buff);
        free(vetor[i].array);
        i++;
        printf("----------------------------------------//----------------------------------------//----------------------------------------\n");
    }
    free(vetor);
    

	return 0;
}
