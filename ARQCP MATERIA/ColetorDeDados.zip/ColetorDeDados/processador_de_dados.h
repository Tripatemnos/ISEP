#ifndef PROCESSADOR_DE_DADOS_H
#define PROCESSADOR_DE_DADOS_H

typedef struct{
	int* buf;
	int lenght;
	int read;
	int write;
} buffer;

typedef struct{
	int id;
	char* type;
	char* unit;
	buffer* buff;
	int* array;
	int lastRead;
	int timeout;
	int write_counter;
} sensor;

sensor* create_struct(char *b);
char* obter_dados(char *a, fpos_t* file_position);
int extract_token(char* input, char* token, int* output);
void insert_struct(sensor *vetor, char *dados);
void enqueue_value(int* array, int length, int* read, int* write, int value);

#endif
