#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "processador_de_dados.h"

char* obter_dados(char *a, fpos_t* file_position) {
    // Abre o arquivo para leitura
    FILE *arquivo = fopen(a, "r");

    // Verifica se o arquivo foi aberto com sucesso
    if (arquivo == NULL) {
        perror("Erro ao abrir o arquivo");
        return NULL;  // Return NULL to indicate failure
    }
    
    fsetpos(arquivo, file_position);

    char linha[100];
    char *line = NULL;  // Dynamically allocated memory for the line

    // Leitura dos dados do arquivo
    if (fgets(linha, sizeof(linha), arquivo) != NULL) {
		if (strcmp(linha,"\n") || strcmp(linha,"")) {
			fgets(linha, sizeof(linha), arquivo);
		}
        linha[strcspn(linha, "\n")] = '\0';

        // Dynamically allocate memory for the line and copy the content
        line = malloc(strlen(linha) + 1);  // +1 for the null terminator
        if (line == NULL) {
            perror("Erro ao alocar memória");
            fclose(arquivo);
            return NULL;
        }
        
		strcpy(line, linha);
    }
    
        // Armazenar a posição atual do arquivo
    fgetpos(arquivo, file_position);

    fclose(arquivo);

    return line;
}
